#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <unistd.h>

#define kPrefPath @"/var/mobile/Library/SBNIPrefs.plist"
#define kLogPath  @"/var/mobile/Library/SBNotifyIcons.log"

@interface DiagVC : UIViewController
@property (nonatomic, copy) NSString *text;
@end

@implementation DiagVC
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor systemBackgroundColor];
    UITextView *tv = [[UITextView alloc] initWithFrame:self.view.bounds];
    tv.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tv.editable = NO;
    tv.font = [UIFont fontWithName:@"Menlo" size:11] ?: [UIFont systemFontOfSize:11];
    tv.text = self.text ?: @"";
    [self.view addSubview:tv];
}
@end

@interface PrefsVC : UIViewController <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *table;
@property (nonatomic, assign) BOOL enabled;
@property (nonatomic, assign) CGFloat iconSize;
@property (nonatomic, assign) CGFloat offsetX;
@property (nonatomic, assign) CGFloat offsetY;
@property (nonatomic, assign) CGFloat offsetXLandscape;
@property (nonatomic, assign) CGFloat offsetYLandscape;
@property (nonatomic, assign) NSInteger maxIcons;
@property (nonatomic, assign) BOOL debugIcon;
@property (nonatomic, assign) BOOL landscapeEnabled;
@end

@implementation PrefsVC

- (instancetype)initWithNibName:(NSString *)n bundle:(NSBundle *)b {
    self = [super initWithNibName:n bundle:b];
    if (self) {
        self.title = @"状态栏通知图标";
        [self loadPrefs];
    }
    return self;
}

- (void)loadPrefs {
    self.enabled = YES;
    self.iconSize = 16;
    self.offsetX = 100;
    self.offsetY = 0;
    self.offsetXLandscape = 300;
    self.offsetYLandscape = 0;
    self.maxIcons = 3;
    self.debugIcon = NO;
    self.landscapeEnabled = YES;
    NSDictionary *d = [NSDictionary dictionaryWithContentsOfFile:kPrefPath];
    if ([d isKindOfClass:[NSDictionary class]] && d.count) {
        id v;
        if ((v = d[@"enabled"]) && [v isKindOfClass:[NSNumber class]]) self.enabled = [v boolValue];
        if ((v = d[@"iconSize"]) && [v isKindOfClass:[NSNumber class]]) self.iconSize = [v floatValue];
        if ((v = d[@"offsetX"]) && [v isKindOfClass:[NSNumber class]]) self.offsetX = [v floatValue];
        if ((v = d[@"offsetY"]) && [v isKindOfClass:[NSNumber class]]) self.offsetY = [v floatValue];
        if ((v = d[@"offsetXLandscape"]) && [v isKindOfClass:[NSNumber class]]) self.offsetXLandscape = [v floatValue];
        if ((v = d[@"offsetYLandscape"]) && [v isKindOfClass:[NSNumber class]]) self.offsetYLandscape = [v floatValue];
        if ((v = d[@"maxIcons"]) && [v isKindOfClass:[NSNumber class]]) self.maxIcons = [v integerValue];
        if ((v = d[@"debugIcon"]) && [v isKindOfClass:[NSNumber class]]) self.debugIcon = [v boolValue];
        if ((v = d[@"landscapeEnabled"]) && [v isKindOfClass:[NSNumber class]]) self.landscapeEnabled = [v boolValue];
    }
}

- (void)persist {
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(doPersist) object:nil];
    [self performSelector:@selector(doPersist) withObject:nil afterDelay:0.15];
}

- (void)doPersist {
    NSDictionary *d = @{ @"enabled": @(self.enabled),
                         @"iconSize": @(self.iconSize),
                         @"offsetX": @(self.offsetX),
                         @"offsetY": @(self.offsetY),
                         @"offsetXLandscape": @(self.offsetXLandscape),
                         @"offsetYLandscape": @(self.offsetYLandscape),
                         @"maxIcons": @(self.maxIcons),
                         @"debugIcon": @(self.debugIcon),
                         @"landscapeEnabled": @(self.landscapeEnabled) };
    NSError *err = nil;
    BOOL ok = [d writeToFile:kPrefPath atomically:YES];
    if (!ok) {
        NSString *alt = [NSTemporaryDirectory() stringByAppendingPathComponent:@"SBNIPrefs.plist"];
        ok = [d writeToFile:alt atomically:YES];
        UIAlertController *a = [UIAlertController alertControllerWithTitle:@"保存失败"
                                                                   message:[NSString stringWithFormat:@"写 %@ 被拒(权限)。已写到 %@。请检查 App 是否以无沙盒签名安装。\n错误:%@", kPrefPath, alt, err.localizedDescription]
                                                            preferredStyle:UIAlertControllerStyleAlert];
        [a addAction:[UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:nil]];
        [self presentViewController:a animated:YES completion:nil];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor systemBackgroundColor];
    self.table = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStyleInsetGrouped];
    self.table.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.table.dataSource = self;
    self.table.delegate = self;
    [self.view addSubview:self.table];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"诊断"
                                                                              style:UIBarButtonItemStylePlain
                                                                             target:self
                                                                             action:@selector(showDiag)];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [NSObject cancelPreviousPerformRequestsWithTarget:self selector:@selector(doPersist) object:nil];
    [self doPersist];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tv { return 4; }

- (NSString *)tableView:(UITableView *)tv titleForHeaderInSection:(NSInteger)s {
    if (s == 0) return @"图标显示";
    if (s == 1) return @"竖屏位置";
    if (s == 2) return @"横屏位置";
    return @"安装状态";
}

- (NSString *)tableView:(UITableView *)tv titleForFooterInSection:(NSInteger)s {
    if (s == 0) return @"改完自动生效，无需重启。";
    if (s == 1) return @"X 从屏幕左边缘起算，Y 向下为正。拖动即时预览。";
    if (s == 2) return @"关闭「横屏显示」后横屏完全不显示；开启时用这组偏移，与竖屏互不影响。";
    return @"点右上角「诊断」可看到每条路径是否命中。";
}

- (NSInteger)tableView:(UITableView *)tv numberOfRowsInSection:(NSInteger)s {
    if (s == 0) return 4;
    if (s == 2) return 3;
    if (s == 3) return 2;
    return 2;
}

- (void)placeAccessory:(UIView *)v inCell:(UITableViewCell *)cell {
    CGFloat cw = self.table.bounds.size.width - 40;
    CGFloat w = 150;
    v.frame = CGRectMake(cw - w - 12, 7, w, 30);
    v.autoresizingMask = UIViewAutoresizingNone;
    v.tag = 999;
    [cell.contentView addSubview:v];
}

- (UITableViewCell *)cellForControl:(UIView *)v {
    for (UITableViewCell *c in self.table.visibleCells) {
        if ([v isDescendantOfView:c]) return c;
    }
    return nil;
}

- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath *)ip {
    static NSString *cid = @"c";
    UITableViewCell *cell = [tv dequeueReusableCellWithIdentifier:cid];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:cid];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    for (UIView *v in cell.contentView.subviews) if (v.tag == 999) [v removeFromSuperview];
    cell.accessoryView = nil;
    cell.textLabel.text = nil;
    cell.detailTextLabel.text = nil;
    cell.detailTextLabel.textColor = [UIColor labelColor];

    if (ip.section == 0) {
        if (ip.row == 0) {
            cell.textLabel.text = @"启用";
            UISwitch *sw = [[UISwitch alloc] init];
            sw.on = self.enabled;
            [sw addTarget:self action:@selector(swChanged:) forControlEvents:UIControlEventValueChanged];
            cell.accessoryView = sw;
        } else if (ip.row == 1) {
            cell.textLabel.text = [NSString stringWithFormat:@"图标大小  %.0f", self.iconSize];
            UISlider *sl = [[UISlider alloc] init];
            sl.tag = 10;
            sl.minimumValue = 8; sl.maximumValue = 24; sl.value = self.iconSize;
            [sl addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
            [self placeAccessory:sl inCell:cell];
        } else if (ip.row == 2) {
            cell.textLabel.text = [NSString stringWithFormat:@"最多显示  %ld", (long)self.maxIcons];
            UIStepper *st = [[UIStepper alloc] init];
            st.minimumValue = 1; st.maximumValue = 8; st.stepValue = 1; st.value = self.maxIcons;
            [st addTarget:self action:@selector(maxChanged:) forControlEvents:UIControlEventValueChanged];
            cell.accessoryView = st;
        } else {
            cell.textLabel.text = @"调试图标(常驻齿轮)";
            UISwitch *sw = [[UISwitch alloc] init];
            sw.on = self.debugIcon;
            [sw addTarget:self action:@selector(debugChanged:) forControlEvents:UIControlEventValueChanged];
            cell.accessoryView = sw;
        }
    } else if (ip.section == 1) {
        if (ip.row == 0) {
            cell.textLabel.text = [NSString stringWithFormat:@"横向偏移  %.0f", self.offsetX];
            UISlider *sl = [[UISlider alloc] init];
            sl.tag = 11;
            sl.minimumValue = -400; sl.maximumValue = 1000; sl.value = self.offsetX;
            [sl addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
            [self placeAccessory:sl inCell:cell];
        } else {
            cell.textLabel.text = [NSString stringWithFormat:@"纵向偏移  %.0f", self.offsetY];
            UISlider *sl = [[UISlider alloc] init];
            sl.tag = 12;
            sl.minimumValue = -60; sl.maximumValue = 160; sl.value = self.offsetY;
            [sl addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
            [self placeAccessory:sl inCell:cell];
        }
    } else if (ip.section == 2) {
        if (ip.row == 0) {
            cell.textLabel.text = @"横屏显示";
            UISwitch *sw = [[UISwitch alloc] init];
            sw.on = self.landscapeEnabled;
            [sw addTarget:self action:@selector(landChanged:) forControlEvents:UIControlEventValueChanged];
            cell.accessoryView = sw;
        } else if (ip.row == 1) {
            cell.textLabel.text = [NSString stringWithFormat:@"横向偏移  %.0f", self.offsetXLandscape];
            UISlider *sl = [[UISlider alloc] init];
            sl.tag = 13;
            sl.minimumValue = -400; sl.maximumValue = 1400; sl.value = self.offsetXLandscape;
            [sl addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
            [self placeAccessory:sl inCell:cell];
        } else {
            cell.textLabel.text = [NSString stringWithFormat:@"纵向偏移  %.0f", self.offsetYLandscape];
            UISlider *sl = [[UISlider alloc] init];
            sl.tag = 14;
            sl.minimumValue = -60; sl.maximumValue = 160; sl.value = self.offsetYLandscape;
            [sl addTarget:self action:@selector(sliderChanged:) forControlEvents:UIControlEventValueChanged];
            [self placeAccessory:sl inCell:cell];
        }
    } else {
        if (ip.row == 0) {
            BOOL ok = [[NSFileManager defaultManager] fileExistsAtPath:kPrefPath];
            cell.textLabel.text = @"配置写入";
            cell.detailTextLabel.text = ok ? @"已落盘" : @"未落盘(用默认值)";
            cell.detailTextLabel.textColor = ok ? [UIColor systemGreenColor] : [UIColor systemRedColor];
        } else {
            BOOL ok = [[NSFileManager defaultManager] fileExistsAtPath:kLogPath];
            cell.textLabel.text = @"插件运行日志";
            cell.detailTextLabel.text = ok ? @"存在" : @"不存在(插件未加载)";
            cell.detailTextLabel.textColor = ok ? [UIColor systemGreenColor] : [UIColor systemRedColor];
        }
    }
    return cell;
}

- (void)swChanged:(UISwitch *)s {
    self.enabled = s.isOn;
    [self persist];
}

- (void)debugChanged:(UISwitch *)s {
    self.debugIcon = s.isOn;
    [self persist];
}

- (void)landChanged:(UISwitch *)s {
    self.landscapeEnabled = s.isOn;
    [self persist];
}

- (void)maxChanged:(UIStepper *)s {
    self.maxIcons = (NSInteger)s.value;
    UITableViewCell *c = [self cellForControl:s];
    if (c) c.textLabel.text = [NSString stringWithFormat:@"最多显示  %ld", (long)self.maxIcons];
    [self persist];
}

- (void)sliderChanged:(UISlider *)sl {
    UITableViewCell *c = [self cellForControl:sl];
    switch (sl.tag) {
        case 10:
            self.iconSize = roundf(sl.value);
            if (c) c.textLabel.text = [NSString stringWithFormat:@"图标大小  %.0f", self.iconSize];
            break;
        case 11:
            self.offsetX = roundf(sl.value);
            if (c) c.textLabel.text = [NSString stringWithFormat:@"横向偏移  %.0f", self.offsetX];
            break;
        case 12:
            self.offsetY = roundf(sl.value);
            if (c) c.textLabel.text = [NSString stringWithFormat:@"纵向偏移  %.0f", self.offsetY];
            break;
        case 13:
            self.offsetXLandscape = roundf(sl.value);
            if (c) c.textLabel.text = [NSString stringWithFormat:@"横向偏移  %.0f", self.offsetXLandscape];
            break;
        case 14:
            self.offsetYLandscape = roundf(sl.value);
            if (c) c.textLabel.text = [NSString stringWithFormat:@"纵向偏移  %.0f", self.offsetYLandscape];
            break;
        default:
            break;
    }
    [self persist];
}

- (void)showDiag {
    NSMutableString *s = [NSMutableString string];
    [s appendString:@"== 路径命中 ==\n"];
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *paths = @[
        @"/var/mobile/Library/PreferenceLoader/Preferences/StatusBarNotifyPrefs.plist",
        @"/Library/PreferenceLoader/Preferences/StatusBarNotifyPrefs.plist",
        @"/var/containers/Bundle/tweaksupport/Library/PreferenceLoader/Preferences/StatusBarNotifyPrefs.plist",
        @"/var/jb/Library/PreferenceLoader/Preferences/StatusBarNotifyPrefs.plist",
        @"/usr/lib/TweakInject/PreferenceLoader.dylib",
        @"/var/containers/Bundle/tweaksupport/usr/lib/TweakInject/PreferenceLoader.dylib",
        @"/usr/lib/PreferenceLoader.dylib",
        @"/var/containers/Bundle/tweaksupport/usr/lib/PreferenceLoader.dylib",
        @"/Library/PreferenceBundles/StatusBarNotifyPrefs.bundle/Info.plist",
        @"/var/mobile/Library/PreferenceBundles/StatusBarNotifyPrefs.bundle/Info.plist",
        @"/Library/MobileSubstrate/DynamicLibraries/StatusBarNotifyAppIcons.dylib",
        @"/var/containers/Bundle/tweaksupport/Library/MobileSubstrate/DynamicLibraries/StatusBarNotifyAppIcons.dylib",
        kPrefPath,
        kLogPath,
    ];
    for (NSString *p in paths) {
        [s appendFormat:@"%@ %@\n", [fm fileExistsAtPath:p] ? @"[OK]  " : @"[MISS]", p];
    }
    [s appendFormat:@"\n== App 自身 ==\nbundle=%@\nuid=%d\n", [[NSBundle mainBundle] bundlePath], (int)getuid()];
    NSString *log = [NSString stringWithContentsOfFile:kLogPath encoding:NSUTF8StringEncoding error:nil];
    if (log.length) {
        NSArray *ls = [log componentsSeparatedByString:@"\n"];
        [s appendString:@"\n== HOOK / EVT（最近80条）==\n"];
        NSMutableArray *keep = [NSMutableArray array];
        for (NSString *ln in ls) {
            if ([ln containsString:@"EVT "] || [ln containsString:@"HOOK "] ||
                [ln containsString:@"METHODS "] || [ln containsString:@"SCAN "] ||
                [ln containsString:@"SELFPATH"] || [ln containsString:@"SELFROOT"] ||
                [ln containsString:@"bids src="]) {
                [keep addObject:ln];
                if (keep.count > 80) [keep removeObjectAtIndex:0];
            }
        }
        for (NSString *ln in keep) [s appendFormat:@"%@\n", ln];
        [s appendString:@"\n== 日志尾部 ==\n"];
        NSUInteger n = ls.count;
        NSUInteger start = n > 20 ? n - 20 : 0;
        for (NSUInteger i = start; i < n; i++) if ([ls[i] length]) [s appendFormat:@"%@\n", ls[i]];
    } else {
        [s appendString:@"(无日志)\n"];
    }
    DiagVC *d = [[DiagVC alloc] init];
    d.text = s;
    d.title = @"诊断";
    [self.navigationController pushViewController:d animated:YES];
}

@end

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

@implementation AppDelegate
- (BOOL)application:(UIApplication *)app didFinishLaunchingWithOptions:(NSDictionary *)opts {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:[[PrefsVC alloc] init]];
    self.window.rootViewController = nav;
    [self.window makeKeyAndVisible];
    return YES;
}
@end

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
