#import <UIKit/UIKit.h>

#ifdef __cplusplus
extern "C" {
#endif

void SBNIAttach(UIView *host);
void SBNIStartPolling(void);
void SBNIStartLockObserver(void);
BOOL SBNIBootGuard(void);
void SBNILogClasses(void);
void SBNIHookNotifications(void);

#ifdef __cplusplus
}
#endif
