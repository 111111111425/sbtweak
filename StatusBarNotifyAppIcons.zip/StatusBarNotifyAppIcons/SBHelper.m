#import "SBHelper.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <dlfcn.h>
#import <sys/stat.h>

#define L(fmt, ...) SBNILog(fmt, ##__VA_ARGS__)

static NSString *const kPrefsDomain = @"com.dev.statusbarnotifyappicons.prefs";
static NSString *const kPrefID = @"com.dev.statusbarnotifyappicons";
static NSString *const kLogPath = @"/var/mobile/Library/SBNotifyIcons.log";

@interface UIImage (SBNIIcon)
+ (UIImage *)_applicationIconImageForBundleIdentifier:(NSString *)bid format:(int)format scale:(CGFloat)scale;
@end

typedef struct {
    BOOL enabled;
    CGFloat iconSize;
    CGFloat offsetX;
    CGFloat offsetY;
    CGFloat offsetXLandscape;
    CGFloat offsetYLandscape;
    BOOL debugIcon;
    BOOL landscapeEnabled;
    NSInteger maxIcons;
} SBNIPrefs;

static UIView *gContainer = nil;
static UIView *gRotView = nil;
static NSArray *gBids = nil;
static NSMutableDictionary *gIconCache = nil;
static BOOL gTickBusy = NO;
static dispatch_source_t gTimer = nil;
static dispatch_source_t gLayoutTimer = nil;
static int gTickCount = 0;

void SBNILog(NSString *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    NSLog(@"[SBNotifyIcons] %@", msg);

    static NSDateFormatter *df = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        df = [NSDateFormatter new];
        df.dateFormat = @"HH:mm:ss";
    });
    NSString *line = [NSString stringWithFormat:@"%@ %@\n", [df stringFromDate:[NSDate date]], msg];
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:kLogPath];
    if (!fh) {
        [[NSFileManager defaultManager] createFileAtPath:kLogPath contents:nil attributes:nil];
        fh = [NSFileHandle fileHandleForWritingAtPath:kLogPath];
    }
    if (fh) {
        @try { [fh seekToEndOfFile]; [fh writeData:[line dataUsingEncoding:NSUTF8StringEncoding]]; }
        @catch (NSException *e) {}
        [fh closeFile];
    }
}

static id SBNIPrefValue(NSString *key, NSString *domain) {
    return CFBridgingRelease(CFPreferencesCopyAppValue((__bridge CFStringRef)key, (__bridge CFStringRef)domain));
}

static SBNIPrefs gPrefsCache;
static time_t gPrefsMtime = 0;
static long gPrefsNsec = 0;
static BOOL gPrefsCached = NO;

static SBNIPrefs SBNIReadPrefs(void) {
    struct stat st;
    BOOL haveFile = (stat("/var/mobile/Library/SBNIPrefs.plist", &st) == 0);
    if (gPrefsCached) {
        if (haveFile && st.st_mtime == gPrefsMtime && st.st_mtimespec.tv_nsec == gPrefsNsec) return gPrefsCache;
        if (!haveFile && gPrefsMtime == 0) return gPrefsCache;
    }
    SBNIPrefs p;
    p.enabled = YES;
    p.iconSize = 16.0f;
    p.offsetX = 100.0f;
    p.offsetY = 0.0f;
    p.offsetXLandscape = 300.0f;
    p.offsetYLandscape = 0.0f;
    p.debugIcon = NO;
    p.landscapeEnabled = YES;
    p.maxIcons = 3;

    NSArray *domains = @[kPrefsDomain, kPrefID];
    NSMutableArray *vals = [NSMutableArray array];
    for (int i = 0; i < 9; i++) [vals addObject:[NSNull null]];
    NSArray *keys = @[@"enabled", @"iconSize", @"offsetX", @"offsetY", @"offsetXLandscape", @"offsetYLandscape", @"maxIcons", @"debugIcon", @"landscapeEnabled"];
    for (NSUInteger i = 0; i < keys.count; i++) {
        for (NSString *d in domains) {
            id v = SBNIPrefValue(keys[i], d);
            if ([v isKindOfClass:[NSNumber class]]) { vals[i] = v; break; }
        }
    }
    if (vals[0] != [NSNull null]) p.enabled  = [vals[0] boolValue];
    if (vals[1] != [NSNull null]) p.iconSize = [vals[1] floatValue];
    if (vals[2] != [NSNull null]) p.offsetX  = [vals[2] floatValue];
    if (vals[3] != [NSNull null]) p.offsetY  = [vals[3] floatValue];
    if (vals[4] != [NSNull null]) p.offsetXLandscape = [vals[4] floatValue];
    if (vals[5] != [NSNull null]) p.offsetYLandscape = [vals[5] floatValue];
    if (vals[6] != [NSNull null]) p.maxIcons = [vals[6] integerValue];
    if (vals[7] != [NSNull null]) p.debugIcon = [vals[7] boolValue];
    if (vals[8] != [NSNull null]) p.landscapeEnabled = [vals[8] boolValue];

    NSDictionary *fd = [NSDictionary dictionaryWithContentsOfFile:@"/var/mobile/Library/SBNIPrefs.plist"];
    if ([fd isKindOfClass:[NSDictionary class]] && fd.count) {
        id v;
        if ((v = fd[@"enabled"]) && [v isKindOfClass:[NSNumber class]]) p.enabled = [v boolValue];
        if ((v = fd[@"iconSize"]) && [v isKindOfClass:[NSNumber class]]) p.iconSize = [v floatValue];
        if ((v = fd[@"offsetX"]) && [v isKindOfClass:[NSNumber class]]) p.offsetX = [v floatValue];
        if ((v = fd[@"offsetY"]) && [v isKindOfClass:[NSNumber class]]) p.offsetY = [v floatValue];
        if ((v = fd[@"offsetXLandscape"]) && [v isKindOfClass:[NSNumber class]]) p.offsetXLandscape = [v floatValue];
        if ((v = fd[@"offsetYLandscape"]) && [v isKindOfClass:[NSNumber class]]) p.offsetYLandscape = [v floatValue];
        if ((v = fd[@"maxIcons"]) && [v isKindOfClass:[NSNumber class]]) p.maxIcons = [v integerValue];
        if ((v = fd[@"debugIcon"]) && [v isKindOfClass:[NSNumber class]]) p.debugIcon = [v boolValue];
        if ((v = fd[@"landscapeEnabled"]) && [v isKindOfClass:[NSNumber class]]) p.landscapeEnabled = [v boolValue];
    }
    if (p.iconSize < 8.0f) p.iconSize = 8.0f;
    if (p.iconSize > 24.0f) p.iconSize = 24.0f;
    if (p.maxIcons < 1) p.maxIcons = 1;
    if (p.maxIcons > 8) p.maxIcons = 8;
    if (p.offsetX < -400) p.offsetX = -400;
    if (p.offsetX > 1000) p.offsetX = 1000;
    if (p.offsetY < -60) p.offsetY = -60;
    if (p.offsetY > 160) p.offsetY = 160;
    if (p.offsetXLandscape < -400) p.offsetXLandscape = -400;
    if (p.offsetXLandscape > 1400) p.offsetXLandscape = 1400;
    if (p.offsetYLandscape < -60) p.offsetYLandscape = -60;
    if (p.offsetYLandscape > 160) p.offsetYLandscape = 160;
    if (haveFile) {
        gPrefsMtime = st.st_mtime;
        gPrefsNsec = st.st_mtimespec.tv_nsec;
    } else {
        gPrefsMtime = 0;
        gPrefsNsec = 0;
    }
    gPrefsCache = p;
    gPrefsCached = YES;
    return p;
}

static UIView *SBNIFindInView(UIView *root, Class cls, int depth) {
    if (!root || depth > 24) return nil;
    if ([root isKindOfClass:cls]) return root;
    for (UIView *sub in root.subviews) {
        UIView *hit = SBNIFindInView(sub, cls, depth + 1);
        if (hit) return hit;
    }
    return nil;
}

static BOOL gDumped = NO;
static NSString *gHostDesc = nil;
static UIWindow *gOverlayWindow = nil;

static UIWindowScene *SBNIActiveScene(void) {
    @try {
        UIApplication *app = [UIApplication sharedApplication];
        if (@available(iOS 13.0, *)) {
            for (UIScene *sc in app.connectedScenes) {
                if (![sc isKindOfClass:[UIWindowScene class]]) continue;
                if (sc.activationState == UISceneActivationStateForegroundActive)
                    return (UIWindowScene *)sc;
            }
            for (UIScene *sc in app.connectedScenes) {
                if ([sc isKindOfClass:[UIWindowScene class]]) return (UIWindowScene *)sc;
            }
        }
    } @catch (NSException *e) { L(@"scene fail: %@", e.reason); }
    return nil;
}

static void SBNITick(void);
static BOOL gLocked = NO;
static BOOL gDisabled = NO;

static BOOL SBNIQueryLocked(void) {
    Class c = NSClassFromString(@"SBLockScreenManager");
    if (c) {
        id mgr = nil;
        @try {
            if ([c respondsToSelector:@selector(sharedInstance)])
                mgr = ((id (*)(id, SEL))objc_msgSend)(c, @selector(sharedInstance));
        } @catch (NSException *e) {}
        if (mgr) {
            for (NSString *sel in @[@"isUILocked", @"isLocked", @"isLockScreenVisible"]) {
                SEL s = NSSelectorFromString(sel);
                if ([mgr respondsToSelector:s]) {
                    @try { return ((BOOL (*)(id, SEL))objc_msgSend)(mgr, s); } @catch (NSException *e) {}
                }
            }
        }
    }
    return gLocked;
}

static void SBNIOnLockNotify(CFNotificationCenterRef center, void *observer, CFStringRef name, const void *object, CFDictionaryRef userInfo) {
    dispatch_async(dispatch_get_main_queue(), ^{
        if (gDisabled) return;
        BOOL locked = SBNIQueryLocked();
        gLocked = locked;
        L(@"LOCK %d", locked ? 1 : 0);
        if (locked) {
            if (gOverlayWindow && !gOverlayWindow.hidden) gOverlayWindow.hidden = YES;
        } else {
            if (gOverlayWindow && gOverlayWindow.hidden) gOverlayWindow.hidden = NO;
            gTickBusy = NO;
        }
    });
}

void SBNIStartLockObserver(void) {
    CFNotificationCenterRef dc = CFNotificationCenterGetDarwinNotifyCenter();
    CFNotificationCenterAddObserver(dc, NULL, SBNIOnLockNotify,
                                   CFSTR("com.apple.springboard.lockcomplete"), NULL,
                                   CFNotificationSuspensionBehaviorDeliverImmediately);
    CFNotificationCenterAddObserver(dc, NULL, SBNIOnLockNotify,
                                   CFSTR("com.apple.springboard.lockstate"), NULL,
                                   CFNotificationSuspensionBehaviorDeliverImmediately);
    L(@"LOCK observer registered");
}

BOOL SBNIBootGuard(void) {
    NSString *path = @"/var/mobile/Library/SBNIBoot.plist";
    NSDictionary *prev = [NSDictionary dictionaryWithContentsOfFile:path];
    CFTimeInterval now = CFAbsoluteTimeGetCurrent();
    NSInteger fastN = 0;
    if (prev) {
        double t = [[prev objectForKey:@"t"] doubleValue];
        NSInteger pn = [[prev objectForKey:@"n"] integerValue];
        if (t > 0 && (now - t) < 20.0) fastN = pn + 1;
    }
    NSMutableDictionary *cur = [NSMutableDictionary dictionary];
    [cur setObject:[NSNumber numberWithDouble:now] forKey:@"t"];
    [cur setObject:[NSNumber numberWithInteger:fastN] forKey:@"n"];
    [cur writeToFile:path atomically:YES];
    L(@"GUARD n=%ld", (long)fastN);
    if (fastN >= 2) {
        gDisabled = YES;
        L(@"GUARD disabled after repeated fast crash");
        return NO;
    }
    return YES;
}

@interface SBNIOverlayVC : UIViewController
@end

@implementation SBNIOverlayVC
- (BOOL)shouldAutorotate { return YES; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskAll;
}
@end

static void SBNIEnsureWindow(void) {
    if (gDisabled) return;
    if (gOverlayWindow && gContainer) {
        if (gOverlayWindow.hidden) gOverlayWindow.hidden = NO;
        return;
    }
    UIWindowScene *scene = SBNIActiveScene();
    if (!scene) { L(@"ensure: no scene"); return; }
    @try {
        gOverlayWindow = [[UIWindow alloc] initWithWindowScene:scene];
        gOverlayWindow.frame = scene.coordinateSpace.bounds;
        gOverlayWindow.windowLevel = 1100.0f;
        gOverlayWindow.backgroundColor = [UIColor clearColor];
        gOverlayWindow.userInteractionEnabled = NO;
        UIViewController *vc = [SBNIOverlayVC new];
        vc.view.backgroundColor = [UIColor clearColor];
        vc.view.userInteractionEnabled = NO;
        gOverlayWindow.rootViewController = vc;
        gOverlayWindow.hidden = NO;

        gRotView = [[UIView alloc] initWithFrame:CGRectZero];
        gRotView.userInteractionEnabled = NO;
        gRotView.backgroundColor = [UIColor clearColor];
        gRotView.autoresizingMask = UIViewAutoresizingNone;
        [vc.view addSubview:gRotView];

        gContainer = [[UIView alloc] initWithFrame:CGRectZero];
        gContainer.userInteractionEnabled = NO;
        gContainer.backgroundColor = [UIColor clearColor];
        [gRotView addSubview:gContainer];
        gHostDesc = @"overlayWindow";

        L(@"overlay created lvl=%.0f frame=%@ scene=%@",
          gOverlayWindow.windowLevel, NSStringFromCGRect(scene.coordinateSpace.bounds),
          NSStringFromClass([scene class]));
    } @catch (NSException *e) {
        L(@"overlay fail: %@", e.reason);
        gOverlayWindow = nil;
        gContainer = nil;
    }
}

static id gFBSObs = nil;
static NSInteger gFBSOri = -1;
static BOOL gFBSTried = NO;

static void SBNIInitFBSObserver(void) {
    if (gFBSTried) return;
    gFBSTried = YES;
    Class c = NSClassFromString(@"FBSOrientationObserver");
    if (!c) { L(@"FBS class=none"); return; }
    @try {
        id obs = ((id (*)(id, SEL))objc_msgSend)(c, @selector(alloc));
        if (obs) obs = ((id (*)(id, SEL))objc_msgSend)(obs, @selector(init));
        if (obs && [obs respondsToSelector:NSSelectorFromString(@"activeInterfaceOrientation")]) {
            gFBSObs = obs;
            L(@"FBS observer=ok");
        } else {
            L(@"FBS observer=unusable");
        }
    } @catch (NSException *e) {
        L(@"FBS init fail %@", e.reason);
        gFBSObs = nil;
    }
}

static NSInteger SBNIPhysicalOrientation(void) {
    id obs = gFBSObs;
    if (!obs) return 0;
    NSInteger o = 0;
    @try {
        o = ((NSInteger (*)(id, SEL))objc_msgSend)(obs, NSSelectorFromString(@"activeInterfaceOrientation"));
    } @catch (NSException *e) { return 0; }
    if (o != gFBSOri) {
        gFBSOri = o;
        L(@"FBS raw=%ld", (long)o);
    }
    if (o == 1 || o == 2 || o == 3 || o == 4) return o;
    return 0;
}

static NSInteger SBNIUIOrientation(void) {
    UIWindowScene *scene = nil;
    @try { scene = gOverlayWindow.windowScene; } @catch (NSException *e) {}
    if (!scene) scene = SBNIActiveScene();
    if (scene && [scene respondsToSelector:@selector(interfaceOrientation)]) {
        @try {
            NSInteger o = ((NSInteger (*)(id, SEL))objc_msgSend)(scene, @selector(interfaceOrientation));
            if (o == 1 || o == 2 || o == 3 || o == 4) return o;
        } @catch (NSException *e) {}
    }
    @try {
        UIApplication *app = [UIApplication sharedApplication];
        if ([app respondsToSelector:@selector(statusBarOrientation)]) {
            NSInteger o = ((NSInteger (*)(id, SEL))objc_msgSend)(app, @selector(statusBarOrientation));
            if (o == 1 || o == 2 || o == 3 || o == 4) return o;
        }
    } @catch (NSException *e) {}
    return 0;
}

static NSInteger SBNICurrentOrientation(void) {
    NSInteger phy = SBNIPhysicalOrientation();
    if (phy) return phy;
    return SBNIUIOrientation();
}

static NSInteger gLandState = 0;
static NSInteger gLandCand = -1;
static CFTimeInterval gLandCandTime = 0;

static BOOL SBNIIsLandscape(void) {
    NSInteger cur = SBNICurrentOrientation();
    if (cur == 0) return gLandState ? YES : NO;
    NSInteger land = (cur == 3 || cur == 4) ? 1 : 0;
    if (land == gLandState) {
        gLandCand = -1;
        return gLandState ? YES : NO;
    }
    if (land == gLandCand) {
        if (CFAbsoluteTimeGetCurrent() - gLandCandTime >= 0.6) {
            gLandState = land;
            gLandCand = -1;
            L(@"ORIENT flip land=%d cur=%ld", (int)land, (long)cur);
        }
    } else {
        gLandCand = land;
        gLandCandTime = CFAbsoluteTimeGetCurrent();
    }
    return gLandState ? YES : NO;
}

static NSArray *SBNIAllWindows(void) {
    NSMutableArray *out = [NSMutableArray array];
    @try {
        UIApplication *app = [UIApplication sharedApplication];
        for (UIWindow *w in app.windows) if (w && ![out containsObject:w]) [out addObject:w];
        if (@available(iOS 13.0, *)) {
            for (UIScene *sc in app.connectedScenes) {
                NSArray *ws = nil;
                @try {
                    if ([sc isKindOfClass:[UIWindowScene class]]) ws = ((UIWindowScene *)sc).windows;
                    else if ([sc respondsToSelector:NSSelectorFromString(@"windows")])
                        ws = ((id (*)(id, SEL))objc_msgSend)(sc, NSSelectorFromString(@"windows"));
                } @catch (NSException *e) {}
                if (![ws isKindOfClass:[NSArray class]]) {
                    id v = nil;
                    @try { v = [sc valueForKey:@"windows"]; } @catch (NSException *e) {}
                    if ([v isKindOfClass:[NSArray class]]) ws = v;
                }
                for (id w in ws) {
                    if ([w isKindOfClass:[UIWindow class]] && ![out containsObject:w]) [out addObject:w];
                }
            }
        }
    } @catch (NSException *e) { L(@"allwindows fail: %@", e.reason); }
    return out;
}

static void SBNICollectSBViews(UIView *v, int depth, NSMutableString *sb) {
    if (!v || depth > 26 || sb.length > 2200) return;
    NSString *cn = NSStringFromClass([v class]);
    if ([cn containsString:@"StatusBar"]) {
        [sb appendFormat:@" | %d:%@%@", depth, cn, NSStringFromCGRect(v.frame)];
    }
    for (UIView *s in v.subviews) SBNICollectSBViews(s, depth + 1, sb);
}

static UIView *SBNIFindByName(UIView *root, NSString *needle, int depth) {
    if (!root || depth > 30) return nil;
    if ([NSStringFromClass([root class]) containsString:needle]) return root;
    for (UIView *s in root.subviews) {
        UIView *h = SBNIFindByName(s, needle, depth + 1);
        if (h) return h;
    }
    return nil;
}

static id SBNISBManager(void) {
    Class mgrCls = NSClassFromString(@"SBStatusBarManager");
    if (!mgrCls) return nil;
    @try { return ((id (*)(id, SEL))objc_msgSend)(mgrCls, @selector(sharedInstance)); } @catch (NSException *e) { return nil; }
}

static void SBNIDumpOnce(NSArray *wins) {
    if (gDumped) return;
    gDumped = YES;
    NSMutableString *d = [NSMutableString stringWithFormat:@"windows=%lu", (unsigned long)wins.count];
    for (UIWindow *w in wins)
        [d appendFormat:@" | %@ L%.0f %@", NSStringFromClass([w class]), w.windowLevel, NSStringFromCGRect(w.frame)];
    L(@"DUMP %@", d);

    NSMutableString *sb = [NSMutableString string];
    for (UIWindow *w in wins) SBNICollectSBViews(w, 0, sb);
    L(@"DUMP sbviews%@", sb.length ? sb : @" NONE");

    id mgr = SBNISBManager();
    L(@"DUMP SBStatusBarManager=%@", mgr ? @"YES" : @"NO");
    if (mgr) {
        NSMutableString *ms = [NSMutableString string];
        unsigned int n = 0;
        Method *methods = class_copyMethodList(object_getClass(mgr), &n);
        for (unsigned int i = 0; i < n && i < 70; i++) [ms appendFormat:@" %s", sel_getName(method_getName(methods[i]))];
        if (methods) free(methods);
        L(@"DUMP mgrMethods%@", ms);
        for (NSString *k in @[@"statusBarView", @"statusBar", @"_statusBar", @"statusBarController"]) {
            id v = nil;
            @try { v = [mgr valueForKey:k]; } @catch (NSException *e) {}
            if (v) L(@"DUMP mgr.%@=%@", k, NSStringFromClass([v class]));
        }
    }
}

static UIView * __attribute__((unused)) SBNIFindStatusBar(void) {
    Class cls = NSClassFromString(@"STUIStatusBar");
    Class winCls = NSClassFromString(@"STUIStatusBarWindow");
    NSArray *wins = SBNIAllWindows();
    SBNIDumpOnce(wins);

    // 1) STUIStatusBar 实例（window 树 + rootViewController 树）
    if (cls) {
        for (UIWindow *w in wins) {
            UIView *h = SBNIFindInView(w, cls, 0);
            if (h) { gHostDesc = @"STUIStatusBar"; return h; }
        }
        for (UIWindow *w in wins) {
            UIView *h = SBNIFindInView(w.rootViewController.view, cls, 0);
            if (h) { gHostDesc = @"STUIStatusBar/vc"; return h; }
        }
    }
    // 2) STUIStatusBarWindow 本身
    if (winCls) {
        for (UIWindow *w in wins) {
            if ([w isKindOfClass:winCls]) { gHostDesc = @"STUIStatusBarWindow"; return w; }
        }
    }
    // 3) 任意类名含 StatusBar 的视图
    for (UIWindow *w in wins) {
        UIView *h = SBNIFindByName(w, @"StatusBar", 0);
        if (h) { gHostDesc = [NSString stringWithFormat:@"name:%@", NSStringFromClass([h class])]; return h; }
    }
    // 4) SBStatusBarManager 上的 statusBar 属性
    id mgr = SBNISBManager();
    if (mgr) {
        for (NSString *k in @[@"statusBarView", @"statusBar", @"_statusBar"]) {
            id v = nil;
            @try { v = [mgr valueForKey:k]; } @catch (NSException *e) {}
            if ([v isKindOfClass:[UIView class]]) {
                gHostDesc = [NSString stringWithFormat:@"mgr.%@", k];
                return (UIView *)v;
            }
        }
    }
    return nil;
}

static void SBNILayout(void) {
    if (gDisabled) return;
    UIView *host = gContainer.superview;
    if (!host) return;
    UIView *root = host.superview;
    if (!root) root = host;
    @try {
        UIWindowScene *sc = gOverlayWindow.windowScene;
        if (sc) {
            CGRect nb = sc.coordinateSpace.bounds;
            if (!CGRectEqualToRect(gOverlayWindow.frame, nb)) gOverlayWindow.frame = nb;
        }
    } @catch (NSException *e) {}
    CGRect rb = root.bounds;
    CGFloat rootW = CGRectGetWidth(rb);
    CGFloat rootH = CGRectGetHeight(rb);
    if (rootW < 60 || rootH < 10) return;

    NSInteger cur = SBNICurrentOrientation();
    BOOL land = SBNIIsLandscape();
    BOOL rotate = (land && rootW < rootH && (cur == 3 || cur == 4));
    CGFloat cw = rotate ? rootH : rootW;
    CGFloat ch = rotate ? rootW : rootH;
    CGFloat angle = rotate ? ((cur == 3) ? -M_PI_2 : M_PI_2) : 0.0f;

    host.transform = rotate ? CGAffineTransformMakeRotation(angle) : CGAffineTransformIdentity;
    host.bounds = CGRectMake(0, 0, cw, ch);
    host.center = CGPointMake(rootW / 2.0f, rootH / 2.0f);
    gContainer.frame = CGRectMake(0, 0, cw, ch);

    SBNIPrefs p = SBNIReadPrefs();
    NSUInteger n = gContainer.subviews.count;
    CGFloat s = p.iconSize;
    CGFloat gap = 2.0f;
    CGFloat w = n ? (n * s + (n - 1) * gap) : 0.0f;
    CGFloat ox = land ? p.offsetXLandscape : p.offsetX;
    CGFloat oy = land ? p.offsetYLandscape : p.offsetY;
    CGFloat x = ox;
    if (x < 0) x = 0;
    if (x + s > cw) x = cw - s;
    if (x < 0) x = 0;

    CGFloat y;
    {
        CGFloat ins = 0;
        @try { ins = root.safeAreaInsets.top; } @catch (NSException *e) {}
        if (land) {
            y = 4.0f + oy;
        } else {
            if (ins < 20) ins = 59.0f;
            y = ins + 2.0f + oy;
        }
    }
    if (y < 0) y = 0;
    if (y + s > ch) y = ch - s;
    if (y < 0) y = 0;

    CGAffineTransform inv = rotate ? CGAffineTransformMakeRotation(-angle) : CGAffineTransformIdentity;
    if (rotate) {
        CGFloat fixedLy = (angle < 0) ? y : (ch - y - s);
        NSUInteger i2 = 0;
        for (UIView *v in gContainer.subviews) {
            CGRect f = CGRectMake(x + (CGFloat)i2 * (s + gap), fixedLy, s, s);
            if (!CGRectEqualToRect(v.frame, f)) v.frame = f;
            if (!CGAffineTransformEqualToTransform(v.transform, inv)) v.transform = inv;
            i2++;
        }
    } else {
        CGFloat cx = 0;
        for (UIView *v in gContainer.subviews) {
            CGRect f = CGRectMake(x + cx, y, s, s);
            if (!CGRectEqualToRect(v.frame, f)) v.frame = f;
            if (!CGAffineTransformEqualToTransform(v.transform, inv)) v.transform = inv;
            cx += s + gap;
        }
    }

    if (n > 0) {
        static int layN = 0;
        static CGRect lastR = {{0,0},{0,0}};
        CGRect key = CGRectMake(x, y, w, s);
        if (layN < 40 || !CGRectEqualToRect(key, lastR)) {
            if (layN < 40) layN++;
            lastR = key;
            L(@"LAYOUT land=%d rot=%d ang=%.0f ox=%.0f oy=%.0f n=%lu f=%@ cs={%.0f,%.0f}",
              (int)land, (int)rotate, angle, ox, oy, (unsigned long)n,
              NSStringFromCGRect(key), cw, ch);
        }
    }
}

static UIImage *SBNIIconFor(NSString *bid) {
    if (!bid.length) return nil;
    if (!gIconCache) gIconCache = [NSMutableDictionary new];
    UIImage *cached = gIconCache[bid];
    if (cached) return cached;
    UIImage *img = nil;
    @try {
        img = [UIImage _applicationIconImageForBundleIdentifier:bid format:0 scale:2.0];
    } @catch (NSException *e) {
        L(@"icon exception: %@", e.reason);
    }
    if (img) gIconCache[bid] = img;
    return img;
}

static void SBNIRebuild(void) {
    if (gDisabled) return;
    if (!gContainer) return;
    SBNIPrefs p = SBNIReadPrefs();
    for (UIView *v in gContainer.subviews.copy) [v removeFromSuperview];

    NSArray *bids = gBids;
    if (p.debugIcon) bids = @[@"com.apple.Preferences"];
    BOOL land = SBNIIsLandscape();
    if (land && !p.landscapeEnabled) {
        if (!gContainer.hidden) gContainer.hidden = YES;
        return;
    }
    if (!p.enabled || bids.count == 0) {
        if (!gContainer.hidden) gContainer.hidden = YES;
        return;
    }
    gContainer.hidden = NO;
    NSUInteger limit = MIN((NSUInteger)p.maxIcons, bids.count);
    for (NSUInteger i = 0; i < limit; i++) {
        NSString *bid = bids[i];
        UIImage *img = SBNIIconFor(bid);
        if (!img) { L(@"no icon for %@", bid); continue; }
        UIImageView *iv = [[UIImageView alloc] initWithImage:img];
        iv.contentMode = UIViewContentModeScaleAspectFit;
        iv.layer.cornerRadius = p.iconSize * 0.22f;
        iv.clipsToBounds = YES;
        [gContainer addSubview:iv];
    }
    SBNILayout();
    L(@"rebuild: %lu icons container=%@ winHidden=%d",
      (unsigned long)gContainer.subviews.count,
      NSStringFromCGRect(gContainer.frame),
      (gOverlayWindow && gOverlayWindow.hidden) ? 1 : 0);
}

static void __attribute__((unused)) SBNIAttachTo(UIView *host) {
    if (!host) return;
    if (!gContainer) {
        gContainer = [[UIView alloc] initWithFrame:CGRectZero];
        gContainer.userInteractionEnabled = NO;
        gContainer.backgroundColor = [UIColor clearColor];
    }
    [gContainer removeFromSuperview];
    [host addSubview:gContainer];
    L(@"attached to %@ bounds=%@", NSStringFromClass([host class]), NSStringFromCGRect(host.bounds));

    SBNILayout();
    L(@"attached[%@] container=%@", gHostDesc ?: @"?", NSStringFromCGRect(gContainer.frame));

    CGFloat dotY = CGRectGetMidY(gContainer.frame) - 4;
    if (dotY < 0 || dotY > CGRectGetHeight(host.bounds) - 8) dotY = 8;
    UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(CGRectGetWidth(host.bounds) - 22, dotY, 8, 8)];
    dot.backgroundColor = [UIColor redColor];
    dot.userInteractionEnabled = NO;
    [host addSubview:dot];
    L(@"inject verified: red dot");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [dot removeFromSuperview];
    });
}

static NSArray * __attribute__((unused)) SBNIBadgedBundleIDs(void) {
    NSMutableArray *out = [NSMutableArray array];
    @try {
        Class icc = NSClassFromString(@"SBIconController");
        if (!icc) return out;
        id shared = ((id (*)(id, SEL))objc_msgSend)(icc, @selector(sharedInstance));
        if (!shared) return out;
        id model = [shared valueForKey:@"model"];
        if (!model) return out;
        id icons = [model valueForKeyPath:@"leafIcons"];
        NSArray *arr = nil;
        if ([icons isKindOfClass:[NSArray class]]) arr = icons;
        else if ([icons isKindOfClass:[NSSet class]]) arr = [(NSSet *)icons allObjects];
        if (!arr) return out;

        for (id icon in arr) {
            @try {
                id badge = [icon valueForKey:@"badgeNumberOrString"];
                if (!badge || [badge isKindOfClass:[NSNull class]]) continue;
                if ([badge isKindOfClass:[NSNumber class]] && [badge integerValue] == 0) continue;
                NSString *bs = [badge description];
                if (!bs.length || [bs isEqualToString:@"0"]) continue;
                id bid = [icon valueForKey:@"applicationBundleID"];
                if (![bid isKindOfClass:[NSString class]] || ![bid length]) continue;
                if (![out containsObject:bid]) [out addObject:bid];
            } @catch (NSException *e) {}
        }
    } @catch (NSException *e) {
        L(@"badge scan fail: %@", e.reason);
    }
    return [out sortedArrayUsingSelector:@selector(compare:)];
}

static NSArray *SBNIExtractSections(id container) {
    NSMutableArray *out = [NSMutableArray array];
    NSArray *arr = nil;
    if ([container isKindOfClass:[NSArray class]]) arr = container;
    else if ([container isKindOfClass:[NSSet class]]) arr = [(NSSet *)container allObjects];
    else if ([container isKindOfClass:[NSDictionary class]]) arr = [(NSDictionary *)container allValues];
    if (!arr) return out;
    for (id req in arr) {
        NSString *sec = nil;
        @try { sec = [req valueForKey:@"sectionIdentifier"]; } @catch (NSException *e) {}
        if (![sec isKindOfClass:[NSString class]] || !sec.length) {
            @try { sec = [req valueForKey:@"section"]; } @catch (NSException *e) {}
        }
        if ([sec isKindOfClass:[NSString class]] && sec.length && ![out containsObject:sec])
            [out addObject:sec];
    }
    return out;
}

static void SBNIDumpIvars(id obj) {
    if (!obj) return;
    unsigned int n = 0;
    Ivar *ivars = class_copyIvarList(object_getClass(obj), &n);
    NSMutableString *sb = [NSMutableString string];
    for (unsigned int i = 0; i < n && i < 60; i++) {
        const char *nm = ivar_getName(ivars[i]);
        const char *tp = ivar_getTypeEncoding(ivars[i]);
        [sb appendFormat:@" %s:%s", nm ? nm : "?", tp ? tp : "?"];
    }
    if (ivars) free(ivars);
    L(@"IVARS %@%@", NSStringFromClass([obj class]), sb);
}

static id SBNICall(id obj, NSString *sel) {
    if (!obj) return nil;
    SEL s = NSSelectorFromString(sel);
    if (![obj respondsToSelector:s]) return nil;
    @try { return ((id (*)(id, SEL))objc_msgSend)(obj, s); } @catch (NSException *e) { return nil; }
}

static void SBNICollectFromObject(id obj, NSString *tag, NSMutableArray *out) {
    if (!obj) return;
    static NSMutableSet *gLoggedTags = nil;
    if (!gLoggedTags) gLoggedTags = [NSMutableSet set];
    if (![gLoggedTags containsObject:tag]) {
        [gLoggedTags addObject:tag];
        L(@"SCAN %@ -> %@", tag, NSStringFromClass([obj class]));
        SBNIDumpIvars(obj);
    }
    NSArray *keys = @[@"_uuidsToRequests", @"_bulletinsToUUIDs", @"_notificationRequests",
                      @"notificationRequests", @"allNotificationRequests", @"activeNotificationRequests",
                      @"requests", @"_requests", @"bulletinRequests", @"_bulletinRequests",
                      @"sectionInfo", @"_sectionInfo", @"store", @"_store",
                      @"_listModel", @"_notificationListModel", @"_sections", @"_sectionLists",
                      @"_openRequests", @"_readRequests"];
    for (NSString *k in keys) {
        id v = nil;
        @try { v = [obj valueForKey:k]; } @catch (NSException *e) {}
        if (!v) continue;
        NSArray *secs = SBNIExtractSections(v);
        if (secs.count) {
            static BOOL loggedHit = NO;
            if (!loggedHit) {
                L(@"HIT %@.%@ type=%@ sections=%lu", tag, k,
                  NSStringFromClass([v class]), (unsigned long)secs.count);
                loggedHit = YES;
            }
            for (NSString *s in secs) if (![out containsObject:s]) [out addObject:s];
        }
    }
}

static NSArray *SBNINotifiedBundleIDs(void) {
    NSMutableArray *out = [NSMutableArray array];

    UIApplication *app = [UIApplication sharedApplication];
    id disp = SBNICall(app, @"notificationDispatcher");
    if (disp) {
        SBNICollectFromObject(disp, @"dispatcher", out);
        SBNICollectFromObject(SBNICall(disp, @"notificationSource"), @"source", out);
        id dst = nil;
        @try { dst = [disp valueForKey:@"_notificationCenterDestination"]; } @catch (NSException *e) {}
        SBNICollectFromObject(dst, @"dest", out);
    } else {
        L(@"SCAN no notificationDispatcher on UIApplication");
    }

    Class lsm = NSClassFromString(@"SBLockScreenManager");
    if (lsm && [lsm respondsToSelector:NSSelectorFromString(@"sharedInstanceIfExists")]) {
        id mgr = nil;
        @try { mgr = ((id (*)(id, SEL))objc_msgSend)(lsm, NSSelectorFromString(@"sharedInstanceIfExists")); } @catch (NSException *e) {}
        id vc = SBNICall(mgr, @"lockScreenViewController");
        id nc = nil;
        @try { nc = [vc valueForKey:@"notificationController"]; } @catch (NSException *e) {}
        SBNICollectFromObject(nc, @"lockscreenNC", out);
    }

    NSArray *classNames = @[@"NCNotificationCenter", @"SBNotificationCenterController",
                            @"NCNotificationStore", @"NCNotificationDispatcher",
                            @"NCNotificationDestinationsRegistry", @"SBNotificationsController",
                            @"NCNotificationListModel"];
    NSArray *keys = @[@"notificationRequests", @"activeNotificationRequests",
                      @"allNotificationRequests", @"requests", @"_requests",
                      @"_notificationRequests", @"destinations"];
    for (NSString *cn in classNames) {
        Class c = NSClassFromString(cn);
        if (!c) continue;
        id obj = nil;
        for (NSString *sel in @[@"sharedInstance", @"sharedCenter", @"defaultCenter", @"sharedStore"]) {
            if ([c respondsToSelector:NSSelectorFromString(sel)]) {
                @try { obj = ((id (*)(id, SEL))objc_msgSend)(c, NSSelectorFromString(sel)); } @catch (NSException *e) {}
                if (obj) break;
            }
        }
        if (!obj) continue;
        BOOL hit = NO;
        for (NSString *k in keys) {
            id v = nil;
            @try { v = [obj valueForKey:k]; } @catch (NSException *e) {}
            if (!v) continue;
            NSArray *secs = SBNIExtractSections(v);
            if (secs.count) {
                hit = YES;
                L(@"probe %@.%@ %@ n=%lu", cn, k, NSStringFromClass([v class]), (unsigned long)secs.count);
                for (NSString *s in secs) if (![out containsObject:s]) [out addObject:s];
            }
        }
        if (!hit) L(@"probe %@ no data obj=%@", cn, NSStringFromClass([obj class]));
    }
    return out;
}

static void SBNIDumpNotificationClasses(void) {
    int numClasses = objc_getClassList(NULL, 0);
    if (numClasses <= 0) return;
    __unsafe_unretained Class *classes = (__unsafe_unretained Class *)malloc(sizeof(Class) * numClasses);
    if (!classes) return;
    numClasses = objc_getClassList(classes, numClasses);
    NSMutableString *sb = [NSMutableString string];
    for (int i = 0; i < numClasses; i++) {
        NSString *cn = NSStringFromClass(classes[i]);
        if (!cn.length) continue;
        if ([cn containsString:@"Notification"] || [cn containsString:@"Bulletin"]) {
            if (sb.length < 1800) [sb appendFormat:@" %@", cn];
        }
    }
    free(classes);
    L(@"NOTIFCLASSES%@", sb.length ? sb : @" none");
}

static NSString *SBNIDeriveRoot(void) {
    static NSString *root = nil;
    static BOOL done = NO;
    if (done) return root;
    done = YES;
    Dl_info info;
    if (dladdr((const void *)(void *)SBNIDeriveRoot, &info) && info.dli_fname) {
        NSString *p = [NSString stringWithUTF8String:info.dli_fname];
        L(@"SELFPATH %@", p);
        NSString *dl = [p stringByDeletingLastPathComponent];
        NSString *ms = [dl stringByDeletingLastPathComponent];
        NSString *lb = [ms stringByDeletingLastPathComponent];
        root = [lb stringByDeletingLastPathComponent];
        L(@"SELFROOT %@", root);
    }
    return root;
}

static void SBNICheckPrefsInstall(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSString *root = SBNIDeriveRoot();
    NSMutableArray *paths = [NSMutableArray arrayWithArray:@[
        @"/Library/PreferenceLoader/Preferences/StatusBarNotifyPrefs.plist",
        @"/var/containers/Bundle/tweaksupport/Library/PreferenceLoader/Preferences/StatusBarNotifyPrefs.plist",
        @"/var/jb/Library/PreferenceLoader/Preferences/StatusBarNotifyPrefs.plist",
        @"/Library/PreferenceBundles/StatusBarNotifyPrefs.bundle/Info.plist",
        @"/var/containers/Bundle/tweaksupport/Library/PreferenceBundles/StatusBarNotifyPrefs.bundle/Info.plist",
        @"/var/jb/Library/PreferenceBundles/StatusBarNotifyPrefs.bundle/Info.plist",
        @"/usr/lib/PreferenceLoader.dylib",
        @"/var/containers/Bundle/tweaksupport/usr/lib/PreferenceLoader.dylib",
        @"/var/jb/usr/lib/PreferenceLoader.dylib",
    ]];
    if (root.length > 1) {
        NSString *base = [root stringByAppendingPathComponent:@"Library"];
        [paths addObject:[base stringByAppendingPathComponent:@"PreferenceLoader/Preferences/StatusBarNotifyPrefs.plist"]];
        [paths addObject:[base stringByAppendingPathComponent:@"PreferenceBundles/StatusBarNotifyPrefs.bundle/Info.plist"]];
        [paths addObject:[root stringByAppendingPathComponent:@"usr/lib/PreferenceLoader.dylib"]];
    }
    NSMutableString *found = [NSMutableString string];
    NSMutableString *missing = [NSMutableString string];
    for (NSString *p in paths) {
        if ([fm fileExistsAtPath:p]) [found appendFormat:@"%@ ", p];
        else [missing appendFormat:@"%@ ", p];
    }
    L(@"PREFS_FOUND %@", found.length ? found : @"NONE");
    L(@"PREFS_MISS %@", missing.length ? missing : @"NONE");
}

static NSMutableDictionary *gReqSets = nil;  // bid -> NSMutableSet<reqid>

static NSString *SBNIReqID(id req) {
    if (!req) return nil;
    if ([req isKindOfClass:[NSString class]]) return req;
    if ([req isKindOfClass:[NSUUID class]]) return [req UUIDString];
    if ([req isKindOfClass:[NSNumber class]]) return [req description];
    static NSArray *keys = nil;
    if (!keys) keys = @[@"notificationIdentifier", @"requestIdentifier", @"uuid", @"notificationUUID"];
    for (NSString *k in keys) {
        id v = nil;
        @try { v = [req valueForKey:k]; } @catch (NSException *e) { v = nil; }
        if (v && ![v isKindOfClass:[NSNull class]]) {
            NSString *s = [v isKindOfClass:[NSString class]] ? v : [v description];
            if (s.length) return s;
        }
    }
    return nil;
}

static NSString *SBNIBidOf(id req) {
    if (!req) return nil;
    @try {
        id s = [req valueForKey:@"sectionIdentifier"];
        if ([s isKindOfClass:[NSString class]] && [s length]) return s;
    } @catch (NSException *e) {}
    @try {
        id s = [req valueForKey:@"section"];
        id i2 = [s valueForKey:@"identifier"];
        if ([i2 isKindOfClass:[NSString class]] && [i2 length]) return i2;
    } @catch (NSException *e) {}
    return nil;
}

static void SBNIHookRecord(id req, int delta) {
    @try {
        if (gDisabled || gLocked) return;
        NSString *bid = SBNIBidOf(req);
        if (!bid.length) return;
        if (!gReqSets) gReqSets = [NSMutableDictionary dictionary];
        NSMutableSet *set = [gReqSets objectForKey:bid];
        if (!set) { set = [NSMutableSet set]; [gReqSets setObject:set forKey:bid]; }
        NSString *rid = SBNIReqID(req);
        if (rid.length) {
            if (delta > 0) [set addObject:rid];
            else [set removeObject:rid];
        } else {
            // 取不到唯一标识时用固定占位：保证能显示，删除时能清空
            if (delta > 0) [set addObject:@"*"];
            else if ([set containsObject:@"*"]) [set removeObject:@"*"];
            else {
                NSArray *any = [[set allObjects] sortedArrayUsingSelector:@selector(compare:)];
                if (any.count) [set removeObject:[any lastObject]];
            }
        }
        NSUInteger n = set.count;
        if (n == 0) [gReqSets removeObjectForKey:bid];
        static int evtN = 0;
        if (evtN < 60) {
            evtN++;
            NSString *rid6 = rid.length > 6 ? [rid substringToIndex:6] : (rid ?: @"-");
            L(@"EVT %@ %@ %@ n=%lu", delta > 0 ? @"ADD" : @"REM", bid, rid6, (unsigned long)n);
        }
    } @catch (NSException *e) {}
}

static NSArray *SBNIHookBids(void) {
    if (!gReqSets || gReqSets.count == 0) return nil;
    NSMutableArray *ok = [NSMutableArray array];
    for (NSString *k in gReqSets) {
        NSMutableSet *s = [gReqSets objectForKey:k];
        if (s && s.count) [ok addObject:k];
    }
    if (!ok.count) return nil;
    return [ok sortedArrayUsingSelector:@selector(compare:)];
}

static BOOL SBNIReplaceAllWithArray(NSArray *a) {
    if (![a isKindOfClass:[NSArray class]] || !a.count) return NO;
    NSMutableDictionary *nd = [NSMutableDictionary dictionary];
    NSUInteger okCount = 0;
    for (id req in a) {
        NSString *bid = SBNIBidOf(req);
        if (!bid.length) continue;
        NSMutableSet *set = nd[bid];
        if (!set) { set = [NSMutableSet set]; nd[bid] = set; }
        NSString *rid = SBNIReqID(req);
        [set addObject:(rid.length ? rid : @"*")];
        okCount++;
    }
    if (okCount == 0 || nd.count == 0) return NO;
    BOOL same = (nd.count == gReqSets.count);
    if (same) {
        for (NSString *k in nd) {
            NSMutableSet *cur = [gReqSets objectForKey:k];
            if (!cur || ![cur isEqual:nd[k]]) { same = NO; break; }
        }
    }
    if (same) return YES;
    gReqSets = nd;
    return YES;
}

static NSArray *SBNITryRequestArray(id obj) {
    if (!obj) return nil;
    static NSArray *sels = nil;
    if (!sels) sels = @[@"openRequests", @"_openRequests",
                        @"activeNotificationRequests", @"notificationRequests",
                        @"_notificationRequests", @"requests", @"_requests",
                        @"allNotificationRequests"];
    for (NSString *s in sels) {
        id v = SBNICall(obj, s);
        if (![v isKindOfClass:[NSArray class]] || [(NSArray *)v count] == 0) continue;
        NSArray *arr = v;
        if (SBNIBidOf(arr[0])) return arr;
    }
    return nil;
}

static NSArray *SBNIFetchAllRequests(void) {
    UIApplication *app = [UIApplication sharedApplication];
    id disp = SBNICall(app, @"notificationDispatcher");
    NSArray *out = SBNITryRequestArray(disp);
    if (out) return out;
    out = SBNITryRequestArray(SBNICall(disp, @"notificationSource"));
    if (out) return out;

    static NSArray *classes = nil;
    if (!classes) classes = @[@"NCNotificationDispatcher", @"SBNCNotificationDispatcher",
                              @"NCNotificationStore", @"NCNotificationListModel",
                              @"NCNotificationCenter", @"SBNotificationsController"];
    static NSArray *factory = nil;
    if (!factory) factory = @[@"sharedInstance", @"sharedDispatcher", @"sharedStore", @"sharedCenter"];
    for (NSString *cn in classes) {
        Class c = NSClassFromString(cn);
        if (!c) continue;
        for (NSString *f in factory) {
            id o = SBNICall((id)c, f);
            if (!o) continue;
            out = SBNITryRequestArray(o);
            if (out) return out;
            out = SBNITryRequestArray(SBNICall(o, @"notificationDispatcher"));
            if (out) return out;
        }
    }
    return nil;
}

static NSMutableSet *gHookedIMPs = nil;

static void SBNIInstallOne(Method m, NSString *tag, NSString *selName, int delta, int argc) {
    IMP orig = method_getImplementation(m);
    if (!orig) return;
    if (!gHookedIMPs) gHookedIMPs = [NSMutableSet set];
    NSValue *key = [NSValue valueWithPointer:(void *)orig];
    if ([gHookedIMPs containsObject:key]) return;
    [gHookedIMPs addObject:key];
    SEL s = method_getName(m);
    IMP ni = nil;
    if (argc <= 1) {
        ni = imp_implementationWithBlock(^(id slf, id req){
            SBNIHookRecord(req, delta);
            ((void (*)(id, SEL, id))orig)(slf, s, req);
        });
    } else {
        ni = imp_implementationWithBlock(^(id slf, id req, id extra){
            SBNIHookRecord(req, delta);
            ((void (*)(id, SEL, id, id))orig)(slf, s, req, extra);
        });
    }
    if (ni) {
        method_setImplementation(m, ni);
        L(@"HOOK %@ %@ delta=%d argc=%d", tag, selName, delta, argc);
    }
}

static void SBNIScanClass(Class cls, NSString *tag) {
    if (!cls) { L(@"SCANC %@ nil", tag); return; }
    unsigned int n = 0;
    Method *ms = class_copyMethodList(cls, &n);
    if (!ms) return;
    NSMutableString *names = [NSMutableString string];
    for (unsigned int i = 0; i < n; i++) {
        NSString *sn = NSStringFromSelector(method_getName(ms[i]));
        if (names.length < 900) [names appendFormat:@" %@", sn];
        if (![sn containsString:@"NotificationRequest"]) continue;
        NSArray *parts = [sn componentsSeparatedByString:@":"];
        if (parts.count < 2 || parts.count > 3) continue;
        NSString *low = sn.lowercaseString;
        BOOL isAdd = [low containsString:@"receive"] || [low containsString:@"add"] ||
                     [low containsString:@"present"] || [low containsString:@"post"];
        BOOL isRem = [low containsString:@"remove"] || [low containsString:@"withdraw"] ||
                     [low containsString:@"clear"] || [low containsString:@"dismiss"] ||
                     [low containsString:@"cancel"];
        if (!isAdd && !isRem) continue;
        SBNIInstallOne(ms[i], tag, sn, isRem ? -1 : 1, (int)(parts.count - 1));
    }
    free(ms);
    L(@"METHODS %@:%@", tag, names.length ? names : @" empty");
}

void SBNIHookNotifications(void) {
    Class c1 = NSClassFromString(@"NCNotificationDispatcher");
    Class c2 = NSClassFromString(@"SBNCNotificationDispatcher");
    Class c3 = NSClassFromString(@"NCNotificationDispatcherDelegate");
    Class c4 = NSClassFromString(@"NCNotificationListSection");
    Class c5 = NSClassFromString(@"NCNotificationListModel");
    Class c6 = NSClassFromString(@"NCNotificationStore");
    Class c7 = NSClassFromString(@"SBNotificationCenterDestination");
    SBNIScanClass(c1, @"NC");
    if (c2 && c2 != c1) SBNIScanClass(c2, @"SBNC");
    if (c3) SBNIScanClass(c3, @"NCDel");
    if (c4) SBNIScanClass(c4, @"Sec");
    if (c5) SBNIScanClass(c5, @"Model");
    if (c6) SBNIScanClass(c6, @"Store");
    if (c7) SBNIScanClass(c7, @"Dest");
    L(@"HOOK done hooked=%lu", (unsigned long)gHookedIMPs.count);
}

static NSArray *SBNICurrentBundleIDs(NSString **srcOut) {
    NSDate *now = [NSDate date];
    static NSDate *lastFull = nil;
    BOOL empty = (!gReqSets || gReqSets.count == 0);
    CGFloat fullGap = empty ? 3.0 : 12.0;
    if (!lastFull || [now timeIntervalSinceDate:lastFull] >= fullGap) {
        lastFull = now;
        NSArray *all = SBNIFetchAllRequests();
        if (all) {
            NSMutableString *ds = [NSMutableString string];
            for (id req in all) {
                NSString *b = SBNIBidOf(req);
                if (b.length) [ds appendFormat:@"%@ ", b];
            }
            NSString *line = ds.length > 300 ? [ds substringToIndex:300] : ds;
            static int fsN = 0;
            if (fsN < 40) {
                fsN++;
                L(@"EVT FULLSYNC n=%lu [%@]", (unsigned long)all.count, line);
            }
            SBNIReplaceAllWithArray(all);
        }
    }
    NSArray *hb = SBNIHookBids();
    if (hb.count) {
        if (srcOut) *srcOut = @"hook";
        return hb;
    }
    static NSDate *lastProbe = nil;
    if (!lastProbe || [now timeIntervalSinceDate:lastProbe] >= 30.0) {
        lastProbe = now;
        NSArray *notified = SBNINotifiedBundleIDs();
        if (notified.count) {
            if (srcOut) *srcOut = @"notif";
            return notified;
        }
    }
    if (srcOut) *srcOut = @"none";
    return @[];
}

static void SBNIApplyPrefsIfChanged(void) {
    if (gDisabled) return;
    if (gLocked) return;
    static CGFloat lastSize = -1;
    static NSInteger lastMax = -1;
    static int lastDebug = -1;
    static int lastEnabled = -1;
    static int lastLand = -1;
    static int lastLEn = -1;
    SBNIPrefs p = SBNIReadPrefs();
    int land = SBNIIsLandscape() ? 1 : 0;
    if (p.iconSize != lastSize || p.maxIcons != lastMax ||
        (int)p.debugIcon != lastDebug || (int)p.enabled != lastEnabled ||
        (int)p.landscapeEnabled != lastLEn || land != lastLand) {
        lastSize = p.iconSize;
        lastMax = p.maxIcons;
        lastDebug = (int)p.debugIcon;
        lastEnabled = (int)p.enabled;
        lastLEn = (int)p.landscapeEnabled;
        lastLand = land;
        SBNIRebuild();
        return;
    }
    SBNILayout();
}

static void SBNITick(void) {
    gTickCount++;
    if (gDisabled) return;
    if (gTickBusy) return;
    BOOL locked = SBNIQueryLocked();
    gLocked = locked;
    if (locked) {
        if (gOverlayWindow && !gOverlayWindow.hidden) gOverlayWindow.hidden = YES;
        return;
    }
    if (gTickCount <= 5 || gTickCount % 60 == 0) L(@"tick#%d", gTickCount);
    gTickBusy = YES;
    @try {
        SBNIEnsureWindow();
        if (!gOverlayWindow || !gContainer) {
            static int miss = 0;
            miss++;
            if (miss % 10 == 1) L(@"tick: no overlay (miss=%d)", miss);
            gTickBusy = NO;
            return;
        }
        SBNILayout();
        NSString *src = nil;
        NSArray *found = SBNICurrentBundleIDs(&src);
        if (!gBids || ![gBids isEqualToArray:found]) {
            gBids = found;
            L(@"bids src=%@ count=%lu", src ?: @"?", (unsigned long)found.count);
            SBNIRebuild();
        }
        SBNIApplyPrefsIfChanged();
    } @catch (NSException *e) {
        L(@"tick fail: %@", e.reason);
    }
    gTickBusy = NO;
}

void SBNIStartPolling(void) {
    L(@"polling scheduled");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (gDisabled) { L(@"polling skipped (guard disabled)"); return; }
        SBNIInitFBSObserver();
        gLocked = SBNIQueryLocked();
        L(@"LOCK init %d", gLocked ? 1 : 0);
        if (gTimer) { L(@"timer already running"); return; }
        dispatch_source_t t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
        if (!t) { L(@"timer create fail"); return; }
        dispatch_source_set_timer(t,
                                  dispatch_time(DISPATCH_TIME_NOW, 0),
                                  (uint64_t)(4.0 * NSEC_PER_SEC),
                                  (uint64_t)(1.0 * NSEC_PER_SEC));
        dispatch_source_set_event_handler(t, ^{ SBNITick(); });
        gTimer = t;
        dispatch_resume(t);
        L(@"polling started 4s (timer held=%d)", gTimer ? 1 : 0);
        if (!gLayoutTimer) {
            dispatch_source_t lt = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
            if (lt) {
                dispatch_source_set_timer(lt,
                                          dispatch_time(DISPATCH_TIME_NOW, 0),
                                          (uint64_t)(0.6 * NSEC_PER_SEC),
                                          (uint64_t)(0.25 * NSEC_PER_SEC));
                dispatch_source_set_event_handler(lt, ^{ SBNIApplyPrefsIfChanged(); });
                gLayoutTimer = lt;
                dispatch_resume(lt);
                L(@"layout timer started 0.6s");
            }
        }
    });
}

void SBNILogClasses(void) {
    Class stui = NSClassFromString(@"STUIStatusBar");
    Class icc = NSClassFromString(@"SBIconController");
    L(@"loaded: STUIStatusBar=%@ SBIconController=%@", stui ? @"YES" : @"NO", icc ? @"YES" : @"NO");
    SBNICheckPrefsInstall();
    SBNIDumpNotificationClasses();
}
