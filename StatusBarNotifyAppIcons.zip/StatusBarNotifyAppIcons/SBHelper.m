#import "SBHelper.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>
#import <objc/runtime.h>
#import <objc/message.h>

#define L(fmt, ...) SBNILog(fmt, ##__VA_ARGS__)

static NSString *const kPrefsDomain = @"com.dev.statusbarnotifyappicons.prefs";
static NSString *const kPrefID = @"com.dev.statusbarnotifyappicons";
static NSString *const kLogPath = @"/var/mobile/Library/SBNotifyIcons.log";

@interface UIImage (SBNIIcon)
+ (UIImage *)_applicationIconImageForBundleIdentifier:(NSString *)bid format:(int)format scale:(CGFloat)scale;
@end

typedef struct {
    BOOL enabled;
    CGFloat iconSize;
    CGFloat offsetX;
    CGFloat offsetY;
    NSInteger maxIcons;
} SBNIPrefs;

static UIView *gContainer = nil;
static NSArray *gBids = nil;
static NSMutableDictionary *gIconCache = nil;
static BOOL gTickBusy = NO;
static dispatch_source_t gTimer = nil;
static int gTickCount = 0;

void SBNILog(NSString *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    NSLog(@"[SBNotifyIcons] %@", msg);

    static NSDateFormatter *df = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        df = [NSDateFormatter new];
        df.dateFormat = @"HH:mm:ss";
    });
    NSString *line = [NSString stringWithFormat:@"%@ %@\n", [df stringFromDate:[NSDate date]], msg];
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:kLogPath];
    if (!fh) {
        [[NSFileManager defaultManager] createFileAtPath:kLogPath contents:nil attributes:nil];
        fh = [NSFileHandle fileHandleForWritingAtPath:kLogPath];
    }
    if (fh) {
        @try { [fh seekToEndOfFile]; [fh writeData:[line dataUsingEncoding:NSUTF8StringEncoding]]; }
        @catch (NSException *e) {}
        [fh closeFile];
    }
}

static id SBNIPrefValue(NSString *key, NSString *domain) {
    return CFBridgingRelease(CFPreferencesCopyAppValue((__bridge CFStringRef)key, (__bridge CFStringRef)domain));
}

static SBNIPrefs SBNIReadPrefs(void) {
    SBNIPrefs p;
    p.enabled = YES;
    p.iconSize = 16.0f;
    p.offsetX = 100.0f;
    p.offsetY = 0.0f;
    p.maxIcons = 3;

    NSArray *domains = @[kPrefsDomain, kPrefID];
    NSMutableArray *vals = [NSMutableArray array];
    for (int i = 0; i < 5; i++) [vals addObject:[NSNull null]];
    NSArray *keys = @[@"enabled", @"iconSize", @"offsetX", @"offsetY", @"maxIcons"];
    for (NSUInteger i = 0; i < keys.count; i++) {
        for (NSString *d in domains) {
            id v = SBNIPrefValue(keys[i], d);
            if ([v isKindOfClass:[NSNumber class]]) { vals[i] = v; break; }
        }
    }
    if (vals[0] != [NSNull null]) p.enabled  = [vals[0] boolValue];
    if (vals[1] != [NSNull null]) p.iconSize = [vals[1] floatValue];
    if (vals[2] != [NSNull null]) p.offsetX  = [vals[2] floatValue];
    if (vals[3] != [NSNull null]) p.offsetY  = [vals[3] floatValue];
    if (vals[4] != [NSNull null]) p.maxIcons = [vals[4] integerValue];

    if (p.iconSize < 8.0f) p.iconSize = 8.0f;
    if (p.iconSize > 24.0f) p.iconSize = 24.0f;
    if (p.maxIcons < 1) p.maxIcons = 1;
    if (p.maxIcons > 8) p.maxIcons = 8;
    if (p.offsetX < -200) p.offsetX = -200;
    if (p.offsetX > 400) p.offsetX = 400;
    return p;
}

static UIView *SBNIFindInView(UIView *root, Class cls, int depth) {
    if (!root || depth > 24) return nil;
    if ([root isKindOfClass:cls]) return root;
    for (UIView *sub in root.subviews) {
        UIView *hit = SBNIFindInView(sub, cls, depth + 1);
        if (hit) return hit;
    }
    return nil;
}

static BOOL gDumped = NO;
static NSString *gHostDesc = nil;
static UIWindow *gOverlayWindow = nil;

static UIWindowScene *SBNIActiveScene(void) {
    @try {
        UIApplication *app = [UIApplication sharedApplication];
        if (@available(iOS 13.0, *)) {
            for (UIScene *sc in app.connectedScenes) {
                if (![sc isKindOfClass:[UIWindowScene class]]) continue;
                if (sc.activationState == UISceneActivationStateForegroundActive)
                    return (UIWindowScene *)sc;
            }
            for (UIScene *sc in app.connectedScenes) {
                if ([sc isKindOfClass:[UIWindowScene class]]) return (UIWindowScene *)sc;
            }
        }
    } @catch (NSException *e) { L(@"scene fail: %@", e.reason); }
    return nil;
}

static void SBNIEnsureWindow(void) {
    if (gOverlayWindow && gContainer) {
        if (gOverlayWindow.hidden) gOverlayWindow.hidden = NO;
        return;
    }
    UIWindowScene *scene = SBNIActiveScene();
    if (!scene) { L(@"ensure: no scene"); return; }
    @try {
        gOverlayWindow = [[UIWindow alloc] initWithWindowScene:scene];
        gOverlayWindow.frame = scene.coordinateSpace.bounds;
        gOverlayWindow.windowLevel = 1100.0f;
        gOverlayWindow.backgroundColor = [UIColor clearColor];
        gOverlayWindow.userInteractionEnabled = NO;
        UIViewController *vc = [UIViewController new];
        vc.view.backgroundColor = [UIColor clearColor];
        vc.view.userInteractionEnabled = NO;
        gOverlayWindow.rootViewController = vc;
        gOverlayWindow.hidden = NO;

        gContainer = [[UIView alloc] initWithFrame:CGRectZero];
        gContainer.userInteractionEnabled = NO;
        gContainer.backgroundColor = [UIColor clearColor];
        [vc.view addSubview:gContainer];
        gHostDesc = @"overlayWindow";

        L(@"overlay created lvl=%.0f frame=%@ scene=%@",
          gOverlayWindow.windowLevel, NSStringFromCGRect(scene.coordinateSpace.bounds),
          NSStringFromClass([scene class]));
    } @catch (NSException *e) {
        L(@"overlay fail: %@", e.reason);
        gOverlayWindow = nil;
        gContainer = nil;
    }
}

static NSArray *SBNIAllWindows(void) {
    NSMutableArray *out = [NSMutableArray array];
    @try {
        UIApplication *app = [UIApplication sharedApplication];
        for (UIWindow *w in app.windows) if (w && ![out containsObject:w]) [out addObject:w];
        if (@available(iOS 13.0, *)) {
            for (UIScene *sc in app.connectedScenes) {
                NSArray *ws = nil;
                @try {
                    if ([sc isKindOfClass:[UIWindowScene class]]) ws = ((UIWindowScene *)sc).windows;
                    else if ([sc respondsToSelector:NSSelectorFromString(@"windows")])
                        ws = ((id (*)(id, SEL))objc_msgSend)(sc, NSSelectorFromString(@"windows"));
                } @catch (NSException *e) {}
                if (![ws isKindOfClass:[NSArray class]]) {
                    id v = nil;
                    @try { v = [sc valueForKey:@"windows"]; } @catch (NSException *e) {}
                    if ([v isKindOfClass:[NSArray class]]) ws = v;
                }
                for (id w in ws) {
                    if ([w isKindOfClass:[UIWindow class]] && ![out containsObject:w]) [out addObject:w];
                }
            }
        }
    } @catch (NSException *e) { L(@"allwindows fail: %@", e.reason); }
    return out;
}

static void SBNICollectSBViews(UIView *v, int depth, NSMutableString *sb) {
    if (!v || depth > 26 || sb.length > 2200) return;
    NSString *cn = NSStringFromClass([v class]);
    if ([cn containsString:@"StatusBar"]) {
        [sb appendFormat:@" | %d:%@%@", depth, cn, NSStringFromCGRect(v.frame)];
    }
    for (UIView *s in v.subviews) SBNICollectSBViews(s, depth + 1, sb);
}

static UIView *SBNIFindByName(UIView *root, NSString *needle, int depth) {
    if (!root || depth > 30) return nil;
    if ([NSStringFromClass([root class]) containsString:needle]) return root;
    for (UIView *s in root.subviews) {
        UIView *h = SBNIFindByName(s, needle, depth + 1);
        if (h) return h;
    }
    return nil;
}

static id SBNISBManager(void) {
    Class mgrCls = NSClassFromString(@"SBStatusBarManager");
    if (!mgrCls) return nil;
    @try { return ((id (*)(id, SEL))objc_msgSend)(mgrCls, @selector(sharedInstance)); } @catch (NSException *e) { return nil; }
}

static void SBNIDumpOnce(NSArray *wins) {
    if (gDumped) return;
    gDumped = YES;
    NSMutableString *d = [NSMutableString stringWithFormat:@"windows=%lu", (unsigned long)wins.count];
    for (UIWindow *w in wins)
        [d appendFormat:@" | %@ L%.0f %@", NSStringFromClass([w class]), w.windowLevel, NSStringFromCGRect(w.frame)];
    L(@"DUMP %@", d);

    NSMutableString *sb = [NSMutableString string];
    for (UIWindow *w in wins) SBNICollectSBViews(w, 0, sb);
    L(@"DUMP sbviews%@", sb.length ? sb : @" NONE");

    id mgr = SBNISBManager();
    L(@"DUMP SBStatusBarManager=%@", mgr ? @"YES" : @"NO");
    if (mgr) {
        NSMutableString *ms = [NSMutableString string];
        unsigned int n = 0;
        Method *methods = class_copyMethodList(object_getClass(mgr), &n);
        for (unsigned int i = 0; i < n && i < 70; i++) [ms appendFormat:@" %s", sel_getName(method_getName(methods[i]))];
        if (methods) free(methods);
        L(@"DUMP mgrMethods%@", ms);
        for (NSString *k in @[@"statusBarView", @"statusBar", @"_statusBar", @"statusBarController"]) {
            id v = nil;
            @try { v = [mgr valueForKey:k]; } @catch (NSException *e) {}
            if (v) L(@"DUMP mgr.%@=%@", k, NSStringFromClass([v class]));
        }
    }
}

static UIView *SBNIFindStatusBar(void) {
    Class cls = NSClassFromString(@"STUIStatusBar");
    Class winCls = NSClassFromString(@"STUIStatusBarWindow");
    NSArray *wins = SBNIAllWindows();
    SBNIDumpOnce(wins);

    // 1) STUIStatusBar 实例（window 树 + rootViewController 树）
    if (cls) {
        for (UIWindow *w in wins) {
            UIView *h = SBNIFindInView(w, cls, 0);
            if (h) { gHostDesc = @"STUIStatusBar"; return h; }
        }
        for (UIWindow *w in wins) {
            UIView *h = SBNIFindInView(w.rootViewController.view, cls, 0);
            if (h) { gHostDesc = @"STUIStatusBar/vc"; return h; }
        }
    }
    // 2) STUIStatusBarWindow 本身
    if (winCls) {
        for (UIWindow *w in wins) {
            if ([w isKindOfClass:winCls]) { gHostDesc = @"STUIStatusBarWindow"; return w; }
        }
    }
    // 3) 任意类名含 StatusBar 的视图
    for (UIWindow *w in wins) {
        UIView *h = SBNIFindByName(w, @"StatusBar", 0);
        if (h) { gHostDesc = [NSString stringWithFormat:@"name:%@", NSStringFromClass([h class])]; return h; }
    }
    // 4) SBStatusBarManager 上的 statusBar 属性
    id mgr = SBNISBManager();
    if (mgr) {
        for (NSString *k in @[@"statusBarView", @"statusBar", @"_statusBar"]) {
            id v = nil;
            @try { v = [mgr valueForKey:k]; } @catch (NSException *e) {}
            if ([v isKindOfClass:[UIView class]]) {
                gHostDesc = [NSString stringWithFormat:@"mgr.%@", k];
                return (UIView *)v;
            }
        }
    }
    return nil;
}

static void SBNILayout(void) {
    UIView *host = gContainer.superview;
    if (!host) return;
    CGRect hb = host.bounds;
    if (CGRectGetWidth(hb) < 60) return;
    if (CGRectGetHeight(hb) < 10) return;

    SBNIPrefs p = SBNIReadPrefs();
    NSUInteger n = gContainer.subviews.count;
    CGFloat s = p.iconSize;
    CGFloat gap = 2.0f;
    CGFloat w = n ? (n * s + (n - 1) * gap) : 0.0f;
    CGFloat x = p.offsetX;
    if (w > 0 && x + w > CGRectGetWidth(hb) - 2) x = CGRectGetWidth(hb) - w - 2;
    if (x < 0) x = 0;

    CGFloat hostH = CGRectGetHeight(hb);
    CGFloat y;
    if (hostH > 120) {
        CGFloat ins = 0;
        @try { ins = host.safeAreaInsets.top; } @catch (NSException *e) {}
        if (ins < 20) ins = 59.0f;
        y = ins + 2.0f + p.offsetY;
    } else {
        y = (hostH - s) / 2.0f + p.offsetY;
    }
    if (y < 0) y = 0;
    if (hostH > s && y + s > hostH) y = hostH - s;

    CGRect cf = CGRectMake(x, y, w, s);
    if (!CGRectEqualToRect(gContainer.frame, cf)) gContainer.frame = cf;

    CGFloat cx = 0;
    for (UIView *v in gContainer.subviews) {
        CGRect f = CGRectMake(cx, 0, s, s);
        if (!CGRectEqualToRect(v.frame, f)) v.frame = f;
        cx += s + gap;
    }
}

static UIImage *SBNIIconFor(NSString *bid) {
    if (!bid.length) return nil;
    if (!gIconCache) gIconCache = [NSMutableDictionary new];
    UIImage *cached = gIconCache[bid];
    if (cached) return cached;
    UIImage *img = nil;
    @try {
        img = [UIImage _applicationIconImageForBundleIdentifier:bid format:0 scale:2.0];
    } @catch (NSException *e) {
        L(@"icon exception: %@", e.reason);
    }
    if (img) gIconCache[bid] = img;
    return img;
}

static void SBNIRebuild(void) {
    if (!gContainer) return;
    SBNIPrefs p = SBNIReadPrefs();
    for (UIView *v in gContainer.subviews.copy) [v removeFromSuperview];

    if (!p.enabled || gBids.count == 0) {
        if (!gContainer.hidden) gContainer.hidden = YES;
        return;
    }
    gContainer.hidden = NO;
    NSUInteger limit = MIN((NSUInteger)p.maxIcons, gBids.count);
    for (NSUInteger i = 0; i < limit; i++) {
        NSString *bid = gBids[i];
        UIImage *img = SBNIIconFor(bid);
        if (!img) { L(@"no icon for %@", bid); continue; }
        UIImageView *iv = [[UIImageView alloc] initWithImage:img];
        iv.contentMode = UIViewContentModeScaleAspectFit;
        iv.layer.cornerRadius = p.iconSize * 0.22f;
        iv.clipsToBounds = YES;
        [gContainer addSubview:iv];
    }
    SBNILayout();
    L(@"rebuild: %lu icons container=%@ winHidden=%d",
      (unsigned long)gContainer.subviews.count,
      NSStringFromCGRect(gContainer.frame),
      (gOverlayWindow && gOverlayWindow.hidden) ? 1 : 0);
}

static void SBNIAttachTo(UIView *host) {
    if (!host) return;
    if (!gContainer) {
        gContainer = [[UIView alloc] initWithFrame:CGRectZero];
        gContainer.userInteractionEnabled = NO;
        gContainer.backgroundColor = [UIColor clearColor];
    }
    [gContainer removeFromSuperview];
    [host addSubview:gContainer];
    L(@"attached to %@ bounds=%@", NSStringFromClass([host class]), NSStringFromCGRect(host.bounds));

    SBNILayout();
    L(@"attached[%@] container=%@", gHostDesc ?: @"?", NSStringFromCGRect(gContainer.frame));

    CGFloat dotY = CGRectGetMidY(gContainer.frame) - 4;
    if (dotY < 0 || dotY > CGRectGetHeight(host.bounds) - 8) dotY = 8;
    UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(CGRectGetWidth(host.bounds) - 22, dotY, 8, 8)];
    dot.backgroundColor = [UIColor redColor];
    dot.userInteractionEnabled = NO;
    [host addSubview:dot];
    L(@"inject verified: red dot");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [dot removeFromSuperview];
    });
}

static NSArray *SBNIBadgedBundleIDs(void) {
    NSMutableArray *out = [NSMutableArray array];
    @try {
        Class icc = NSClassFromString(@"SBIconController");
        if (!icc) return out;
        id shared = ((id (*)(id, SEL))objc_msgSend)(icc, @selector(sharedInstance));
        if (!shared) return out;
        id model = [shared valueForKey:@"model"];
        if (!model) return out;
        id icons = [model valueForKeyPath:@"leafIcons"];
        NSArray *arr = nil;
        if ([icons isKindOfClass:[NSArray class]]) arr = icons;
        else if ([icons isKindOfClass:[NSSet class]]) arr = [(NSSet *)icons allObjects];
        if (!arr) return out;

        for (id icon in arr) {
            @try {
                id badge = [icon valueForKey:@"badgeNumberOrString"];
                if (!badge || [badge isKindOfClass:[NSNull class]]) continue;
                if ([badge isKindOfClass:[NSNumber class]] && [badge integerValue] == 0) continue;
                NSString *bs = [badge description];
                if (!bs.length || [bs isEqualToString:@"0"]) continue;
                id bid = [icon valueForKey:@"applicationBundleID"];
                if (![bid isKindOfClass:[NSString class]] || ![bid length]) continue;
                if (![out containsObject:bid]) [out addObject:bid];
            } @catch (NSException *e) {}
        }
    } @catch (NSException *e) {
        L(@"badge scan fail: %@", e.reason);
    }
    return [out sortedArrayUsingSelector:@selector(compare:)];
}

static NSArray *SBNIExtractSections(id container) {
    NSMutableArray *out = [NSMutableArray array];
    NSArray *arr = nil;
    if ([container isKindOfClass:[NSArray class]]) arr = container;
    else if ([container isKindOfClass:[NSSet class]]) arr = [(NSSet *)container allObjects];
    else if ([container isKindOfClass:[NSDictionary class]]) arr = [(NSDictionary *)container allValues];
    if (!arr) return out;
    for (id req in arr) {
        NSString *sec = nil;
        @try { sec = [req valueForKey:@"sectionIdentifier"]; } @catch (NSException *e) {}
        if (![sec isKindOfClass:[NSString class]] || !sec.length) {
            @try { sec = [req valueForKey:@"section"]; } @catch (NSException *e) {}
        }
        if ([sec isKindOfClass:[NSString class]] && sec.length && ![out containsObject:sec])
            [out addObject:sec];
    }
    return out;
}

static NSArray *SBNINotifiedBundleIDs(void) {
    NSMutableArray *out = [NSMutableArray array];
    NSArray *classNames = @[@"NCNotificationCenter", @"SBNotificationCenterController",
                            @"NCNotificationStore", @"NCNotificationDispatcher",
                            @"NCNotificationDestinationsRegistry", @"SBNotificationsController",
                            @"NCNotificationListModel"];
    NSArray *keys = @[@"notificationRequests", @"activeNotificationRequests",
                      @"allNotificationRequests", @"requests", @"_requests",
                      @"_notificationRequests", @"destinations"];
    for (NSString *cn in classNames) {
        Class c = NSClassFromString(cn);
        if (!c) continue;
        id obj = nil;
        for (NSString *sel in @[@"sharedInstance", @"sharedCenter", @"defaultCenter", @"sharedStore"]) {
            if ([c respondsToSelector:NSSelectorFromString(sel)]) {
                @try { obj = ((id (*)(id, SEL))objc_msgSend)(c, NSSelectorFromString(sel)); } @catch (NSException *e) {}
                if (obj) break;
            }
        }
        if (!obj) continue;
        BOOL hit = NO;
        for (NSString *k in keys) {
            id v = nil;
            @try { v = [obj valueForKey:k]; } @catch (NSException *e) {}
            if (!v) continue;
            NSArray *secs = SBNIExtractSections(v);
            if (secs.count) {
                hit = YES;
                L(@"probe %@.%@ %@ n=%lu", cn, k, NSStringFromClass([v class]), (unsigned long)secs.count);
                for (NSString *s in secs) if (![out containsObject:s]) [out addObject:s];
            }
        }
        if (!hit) L(@"probe %@ no data obj=%@", cn, NSStringFromClass([obj class]));
    }
    return out;
}

static void SBNIDumpNotificationClasses(void) {
    int numClasses = objc_getClassList(NULL, 0);
    if (numClasses <= 0) return;
    __unsafe_unretained Class *classes = (__unsafe_unretained Class *)malloc(sizeof(Class) * numClasses);
    if (!classes) return;
    numClasses = objc_getClassList(classes, numClasses);
    NSMutableString *sb = [NSMutableString string];
    for (int i = 0; i < numClasses; i++) {
        NSString *cn = NSStringFromClass(classes[i]);
        if (!cn.length) continue;
        if ([cn containsString:@"Notification"] || [cn containsString:@"Bulletin"]) {
            if (sb.length < 1800) [sb appendFormat:@" %@", cn];
        }
    }
    free(classes);
    L(@"NOTIFCLASSES%@", sb.length ? sb : @" none");
}

static void SBNICheckPrefsInstall(void) {
    NSFileManager *fm = [NSFileManager defaultManager];
    NSArray *paths = @[
        @"/Library/PreferenceLoader/Preferences/StatusBarNotifyPrefs.plist",
        @"/var/containers/Bundle/tweaksupport/Library/PreferenceLoader/Preferences/StatusBarNotifyPrefs.plist",
        @"/var/jb/Library/PreferenceLoader/Preferences/StatusBarNotifyPrefs.plist",
        @"/Library/PreferenceBundles/StatusBarNotifyPrefs.bundle/Info.plist",
        @"/var/containers/Bundle/tweaksupport/Library/PreferenceBundles/StatusBarNotifyPrefs.bundle/Info.plist",
        @"/var/jb/Library/PreferenceBundles/StatusBarNotifyPrefs.bundle/Info.plist",
        @"/usr/lib/PreferenceLoader.dylib",
        @"/var/containers/Bundle/tweaksupport/usr/lib/PreferenceLoader.dylib",
        @"/var/jb/usr/lib/PreferenceLoader.dylib",
    ];
    for (NSString *p in paths)
        L(@"PREFS %d %@", [fm fileExistsAtPath:p] ? 1 : 0, p);
}

static NSArray *SBNICurrentBundleIDs(NSString **srcOut) {
    NSArray *notified = SBNINotifiedBundleIDs();
    if (notified.count) {
        if (srcOut) *srcOut = @"notif";
        return notified;
    }
    if (srcOut) *srcOut = @"badge";
    return SBNIBadgedBundleIDs();
}

static void SBNIApplyPrefsIfChanged(void) {
    static CGFloat lastSize = -1;
    static NSInteger lastMax = -1;
    static CGFloat lastOX = 9999;
    static CGFloat lastOY = 9999;
    SBNIPrefs p = SBNIReadPrefs();
    if (p.iconSize != lastSize || p.maxIcons != lastMax) {
        lastSize = p.iconSize;
        lastMax = p.maxIcons;
        SBNIRebuild();
        return;
    }
    if (p.offsetX != lastOX || p.offsetY != lastOY) {
        lastOX = p.offsetX;
        lastOY = p.offsetY;
        SBNILayout();
    }
}

static void SBNITick(void) {
    gTickCount++;
    if (gTickCount <= 5 || gTickCount % 30 == 0) L(@"tick#%d", gTickCount);
    if (gTickBusy) return;
    gTickBusy = YES;
    @try {
        SBNIEnsureWindow();
        if (!gOverlayWindow || !gContainer) {
            static int miss = 0;
            miss++;
            if (miss % 10 == 1) L(@"tick: no overlay (miss=%d)", miss);
            gTickBusy = NO;
            return;
        }
        SBNILayout();
        NSString *src = nil;
        NSArray *found = SBNICurrentBundleIDs(&src);
        if (!gBids || ![gBids isEqualToArray:found]) {
            gBids = found;
            L(@"bids src=%@ count=%lu", src ?: @"?", (unsigned long)found.count);
            SBNIRebuild();
        }
        SBNIApplyPrefsIfChanged();
    } @catch (NSException *e) {
        L(@"tick fail: %@", e.reason);
    }
    gTickBusy = NO;
}

void SBNIStartPolling(void) {
    L(@"polling scheduled");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (gTimer) { L(@"timer already running"); return; }
        dispatch_source_t t = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
        if (!t) { L(@"timer create fail"); return; }
        dispatch_source_set_timer(t,
                                  dispatch_time(DISPATCH_TIME_NOW, 0),
                                  (uint64_t)(2.0 * NSEC_PER_SEC),
                                  (uint64_t)(0.5 * NSEC_PER_SEC));
        dispatch_source_set_event_handler(t, ^{ SBNITick(); });
        gTimer = t;
        dispatch_resume(t);
        L(@"polling started 2s (timer held=%d)", gTimer ? 1 : 0);
    });
}

void SBNILogClasses(void) {
    Class stui = NSClassFromString(@"STUIStatusBar");
    Class icc = NSClassFromString(@"SBIconController");
    L(@"loaded: STUIStatusBar=%@ SBIconController=%@", stui ? @"YES" : @"NO", icc ? @"YES" : @"NO");
    SBNICheckPrefsInstall();
    SBNIDumpNotificationClasses();
}
