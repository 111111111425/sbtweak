#import "SBHelper.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreFoundation/CoreFoundation.h>
#import <objc/runtime.h>
#import <objc/message.h>

#define L(fmt, ...) SBNILog(fmt, ##__VA_ARGS__)

static NSString *const kPrefsDomain = @"com.dev.statusbarnotifyappicons.prefs";
static NSString *const kPrefID = @"com.dev.statusbarnotifyappicons";
static NSString *const kLogPath = @"/var/mobile/Library/SBNotifyIcons.log";

@interface UIImage (SBNIIcon)
+ (UIImage *)_applicationIconImageForBundleIdentifier:(NSString *)bid format:(int)format scale:(CGFloat)scale;
@end

typedef struct {
    BOOL enabled;
    CGFloat iconSize;
    CGFloat offsetX;
    CGFloat offsetY;
    NSInteger maxIcons;
} SBNIPrefs;

static UIView *gContainer = nil;
static NSArray *gBids = nil;
static NSMutableDictionary *gIconCache = nil;
static BOOL gTickBusy = NO;

void SBNILog(NSString *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    NSString *msg = [[NSString alloc] initWithFormat:fmt arguments:ap];
    va_end(ap);
    NSLog(@"[SBNotifyIcons] %@", msg);

    static NSDateFormatter *df = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        df = [NSDateFormatter new];
        df.dateFormat = @"HH:mm:ss";
    });
    NSString *line = [NSString stringWithFormat:@"%@ %@\n", [df stringFromDate:[NSDate date]], msg];
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:kLogPath];
    if (!fh) {
        [[NSFileManager defaultManager] createFileAtPath:kLogPath contents:nil attributes:nil];
        fh = [NSFileHandle fileHandleForWritingAtPath:kLogPath];
    }
    if (fh) {
        @try { [fh seekToEndOfFile]; [fh writeData:[line dataUsingEncoding:NSUTF8StringEncoding]]; }
        @catch (NSException *e) {}
        [fh closeFile];
    }
}

static id SBNIPrefValue(NSString *key, NSString *domain) {
    return CFBridgingRelease(CFPreferencesCopyAppValue((__bridge CFStringRef)key, (__bridge CFStringRef)domain));
}

static SBNIPrefs SBNIReadPrefs(void) {
    SBNIPrefs p;
    p.enabled = YES;
    p.iconSize = 16.0f;
    p.offsetX = 100.0f;
    p.offsetY = 0.0f;
    p.maxIcons = 3;

    NSArray *domains = @[kPrefsDomain, kPrefID];
    NSMutableArray *vals = [NSMutableArray array];
    for (int i = 0; i < 5; i++) [vals addObject:[NSNull null]];
    NSArray *keys = @[@"enabled", @"iconSize", @"offsetX", @"offsetY", @"maxIcons"];
    for (NSUInteger i = 0; i < keys.count; i++) {
        for (NSString *d in domains) {
            id v = SBNIPrefValue(keys[i], d);
            if ([v isKindOfClass:[NSNumber class]]) { vals[i] = v; break; }
        }
    }
    if (vals[0] != [NSNull null]) p.enabled  = [vals[0] boolValue];
    if (vals[1] != [NSNull null]) p.iconSize = [vals[1] floatValue];
    if (vals[2] != [NSNull null]) p.offsetX  = [vals[2] floatValue];
    if (vals[3] != [NSNull null]) p.offsetY  = [vals[3] floatValue];
    if (vals[4] != [NSNull null]) p.maxIcons = [vals[4] integerValue];

    if (p.iconSize < 8.0f) p.iconSize = 8.0f;
    if (p.iconSize > 24.0f) p.iconSize = 24.0f;
    if (p.maxIcons < 1) p.maxIcons = 1;
    if (p.maxIcons > 8) p.maxIcons = 8;
    if (p.offsetX < -200) p.offsetX = -200;
    if (p.offsetX > 400) p.offsetX = 400;
    return p;
}

static UIView *SBNIFindInView(UIView *root, Class cls, int depth) {
    if (!root || depth > 24) return nil;
    if ([root isKindOfClass:cls]) return root;
    for (UIView *sub in root.subviews) {
        UIView *hit = SBNIFindInView(sub, cls, depth + 1);
        if (hit) return hit;
    }
    return nil;
}

static UIView *SBNIFindStatusBar(void) {
    Class cls = NSClassFromString(@"STUIStatusBar");
    if (!cls) return nil;
    @try {
        NSArray *wins = [UIApplication sharedApplication].windows;
        for (UIWindow *w in wins) {
            UIView *hit = SBNIFindInView(w, cls, 0);
            if (hit) return hit;
        }
        for (UIWindow *w in wins) {
            UIView *hit = SBNIFindInView(w.rootViewController.view, cls, 0);
            if (hit) return hit;
        }
    } @catch (NSException *e) {
        L(@"find statusbar fail: %@", e.reason);
    }
    return nil;
}

static void SBNILayout(void) {
    UIView *host = gContainer.superview;
    if (!host) return;
    CGRect hb = host.bounds;
    if (CGRectGetWidth(hb) < 60) return;
    if (CGRectGetHeight(hb) < 10) return;

    SBNIPrefs p = SBNIReadPrefs();
    NSUInteger n = gContainer.subviews.count;
    CGFloat s = p.iconSize;
    CGFloat gap = 2.0f;
    CGFloat w = n ? (n * s + (n - 1) * gap) : 0.0f;
    CGFloat x = p.offsetX;
    if (w > 0 && x + w > CGRectGetWidth(hb) - 2) x = CGRectGetWidth(hb) - w - 2;
    if (x < 0) x = 0;
    CGFloat y = (CGRectGetHeight(hb) - s) / 2.0f + p.offsetY;

    CGRect cf = CGRectMake(x, y, w, s);
    if (!CGRectEqualToRect(gContainer.frame, cf)) gContainer.frame = cf;

    CGFloat cx = 0;
    for (UIView *v in gContainer.subviews) {
        CGRect f = CGRectMake(cx, 0, s, s);
        if (!CGRectEqualToRect(v.frame, f)) v.frame = f;
        cx += s + gap;
    }
}

static UIImage *SBNIIconFor(NSString *bid) {
    if (!bid.length) return nil;
    if (!gIconCache) gIconCache = [NSMutableDictionary new];
    UIImage *cached = gIconCache[bid];
    if (cached) return cached;
    UIImage *img = nil;
    @try {
        img = [UIImage _applicationIconImageForBundleIdentifier:bid format:0 scale:2.0];
    } @catch (NSException *e) {
        L(@"icon exception: %@", e.reason);
    }
    if (img) gIconCache[bid] = img;
    return img;
}

static void SBNIRebuild(void) {
    if (!gContainer) return;
    SBNIPrefs p = SBNIReadPrefs();
    for (UIView *v in gContainer.subviews.copy) [v removeFromSuperview];

    if (!p.enabled || gBids.count == 0) {
        if (!gContainer.hidden) gContainer.hidden = YES;
        return;
    }
    gContainer.hidden = NO;
    NSUInteger limit = MIN((NSUInteger)p.maxIcons, gBids.count);
    for (NSUInteger i = 0; i < limit; i++) {
        NSString *bid = gBids[i];
        UIImage *img = SBNIIconFor(bid);
        if (!img) { L(@"no icon for %@", bid); continue; }
        UIImageView *iv = [[UIImageView alloc] initWithImage:img];
        iv.contentMode = UIViewContentModeScaleAspectFit;
        iv.layer.cornerRadius = p.iconSize * 0.22f;
        iv.clipsToBounds = YES;
        [gContainer addSubview:iv];
    }
    SBNILayout();
    L(@"rebuild: %lu icons", (unsigned long)gContainer.subviews.count);
}

static void SBNIAttachTo(UIView *host) {
    if (!host) return;
    if (!gContainer) {
        gContainer = [[UIView alloc] initWithFrame:CGRectZero];
        gContainer.userInteractionEnabled = NO;
        gContainer.backgroundColor = [UIColor clearColor];
    }
    [gContainer removeFromSuperview];
    [host addSubview:gContainer];
    L(@"attached to %@ bounds=%@", NSStringFromClass([host class]), NSStringFromCGRect(host.bounds));

    SBNILayout();

    UIView *dot = [[UIView alloc] initWithFrame:CGRectMake(CGRectGetWidth(host.bounds) - 22,
                                                          (CGRectGetHeight(host.bounds) - 8) / 2.0f, 8, 8)];
    dot.backgroundColor = [UIColor redColor];
    dot.userInteractionEnabled = NO;
    [host addSubview:dot];
    L(@"inject verified: red dot");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [dot removeFromSuperview];
    });
}

static NSArray *SBNIBadgedBundleIDs(void) {
    NSMutableArray *out = [NSMutableArray array];
    @try {
        Class icc = NSClassFromString(@"SBIconController");
        if (!icc) return out;
        id shared = ((id (*)(id, SEL))objc_msgSend)(icc, @selector(sharedInstance));
        if (!shared) return out;
        id model = [shared valueForKey:@"model"];
        if (!model) return out;
        id icons = [model valueForKeyPath:@"leafIcons"];
        NSArray *arr = nil;
        if ([icons isKindOfClass:[NSArray class]]) arr = icons;
        else if ([icons isKindOfClass:[NSSet class]]) arr = [(NSSet *)icons allObjects];
        if (!arr) return out;

        for (id icon in arr) {
            @try {
                id badge = [icon valueForKey:@"badgeNumberOrString"];
                if (!badge || [badge isKindOfClass:[NSNull class]]) continue;
                if ([badge isKindOfClass:[NSNumber class]] && [badge integerValue] == 0) continue;
                NSString *bs = [badge description];
                if (!bs.length || [bs isEqualToString:@"0"]) continue;
                id bid = [icon valueForKey:@"applicationBundleID"];
                if (![bid isKindOfClass:[NSString class]] || ![bid length]) continue;
                if (![out containsObject:bid]) [out addObject:bid];
            } @catch (NSException *e) {}
        }
    } @catch (NSException *e) {
        L(@"badge scan fail: %@", e.reason);
    }
    return [out sortedArrayUsingSelector:@selector(compare:)];
}

static void SBNIApplyPrefsIfChanged(void) {
    static CGFloat lastSize = -1;
    static NSInteger lastMax = -1;
    static CGFloat lastOX = 9999;
    static CGFloat lastOY = 9999;
    SBNIPrefs p = SBNIReadPrefs();
    if (p.iconSize != lastSize || p.maxIcons != lastMax) {
        lastSize = p.iconSize;
        lastMax = p.maxIcons;
        SBNIRebuild();
        return;
    }
    if (p.offsetX != lastOX || p.offsetY != lastOY) {
        lastOX = p.offsetX;
        lastOY = p.offsetY;
        SBNILayout();
    }
}

static void SBNITick(void) {
    if (gTickBusy) return;
    gTickBusy = YES;
    @try {
        UIView *host = SBNIFindStatusBar();
        if (host) {
            if (!gContainer || gContainer.superview != host) {
                SBNIAttachTo(host);
            } else {
                SBNILayout();
            }
            NSArray *found = SBNIBadgedBundleIDs();
            if (!gBids || ![gBids isEqualToArray:found]) {
                gBids = found;
                L(@"bids: %@", [found componentsJoinedByString:@","]);
                SBNIRebuild();
            }
            SBNIApplyPrefsIfChanged();
        }
    } @catch (NSException *e) {
        L(@"tick fail: %@", e.reason);
    }
    gTickBusy = NO;
}

void SBNIStartPolling(void) {
    L(@"polling scheduled");
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(20.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        L(@"step1: find statusbar");
        UIView *host = SBNIFindStatusBar();
        L(@"step1 result: %@", host ? NSStringFromClass([host class]) : @"NIL");
        if (!host) return;

        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            L(@"step2: attach");
            SBNIAttachTo(host);
            L(@"step2 done");

            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                L(@"step3: poll loop");
                dispatch_source_t timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, dispatch_get_main_queue());
                if (!timer) return;
                dispatch_source_set_timer(timer,
                                          dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)),
                                          (uint64_t)(2.0 * NSEC_PER_SEC),
                                          (uint64_t)(1.0 * NSEC_PER_SEC));
                dispatch_source_set_event_handler(timer, ^{ SBNITick(); });
                dispatch_resume(timer);
                L(@"polling started");
            });
        });
    });
}

void SBNILogClasses(void) {
    Class stui = NSClassFromString(@"STUIStatusBar");
    Class icc = NSClassFromString(@"SBIconController");
    L(@"loaded: STUIStatusBar=%@ SBIconController=%@", stui ? @"YES" : @"NO", icc ? @"YES" : @"NO");
}
