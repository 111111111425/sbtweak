#import <Preferences/Preferences.h>
#import <CoreFoundation/CoreFoundation.h>

#define PREF_ID @"com.dev.statusbarnotifyappicons.prefs"

@interface StatusBarNotifyPrefsListController : PSListController
@end

@implementation StatusBarNotifyPrefsListController

- (id)specifiers {
    if (!_specifiers) {
        _specifiers = [self loadSpecifiersFromPlistName:@"Root" target:self];
    }
    return _specifiers;
}

- (void)setPreferenceValue:(id)value specifier:(PSSpecifier *)specifier {
    [super setPreferenceValue:value specifier:specifier];
    CFPreferencesAppSynchronize((__bridge CFStringRef)PREF_ID);
    CFPreferencesAppSynchronize(CFSTR("com.dev.statusbarnotifyappicons"));
}

@end
