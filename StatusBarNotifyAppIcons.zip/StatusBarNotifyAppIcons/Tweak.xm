#import "SBHelper.h"

%ctor {
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/Library/SBNotifyIcons.disable"]) {
        NSLog(@"[SBNotifyIcons] disabled by kill switch file");
        return;
    }
    if (!SBNIBootGuard()) {
        NSLog(@"[SBNotifyIcons] disabled by boot guard");
        return;
    }
    SBNILogClasses();
    SBNIHookNotifications();
    SBNIStartLockObserver();
    SBNIStartPolling();
}
