#import "SBHelper.h"

%ctor {
    if ([[NSFileManager defaultManager] fileExistsAtPath:@"/var/mobile/Library/SBNotifyIcons.disable"]) {
        NSLog(@"[SBNotifyIcons] disabled by kill switch file");
        return;
    }
    SBNILogClasses();
    SBNIHookNotifications();
    SBNIStartPolling();
}
