#!/bin/bash
set -e

export THEOS="$(pwd)/theos"
export THEOS_PACKAGE_SCHEME=rootless
export ARCHS=arm64e

echo "========================================"
echo "Step 1/4: build preference bundle (arm64e)"
echo "========================================"
cd StatusBarNotifyPrefs
gmake clean
gmake package FINALPACKAGE=1 ARCHS=arm64e THEOS_PACKAGE_SCHEME=rootless
cd ..

echo "========================================"
echo "Step 2/4: build tweak dylib (arm64e)"
echo "========================================"
gmake clean
gmake package FINALPACKAGE=1 ARCHS=arm64e THEOS_PACKAGE_SCHEME=rootless

echo "========================================"
echo "Step 3/4: verify architecture"
echo "========================================"
DYLIB=$(find .theos -name "StatusBarNotifyAppIcons.dylib" 2>/dev/null | head -1)
if [ -n "$DYLIB" ]; then
  echo "dylib: $DYLIB"
  lipo -info "$DYLIB" || true
else
  echo "WARNING: dylib not found in .theos, checking deb"
fi

echo "========================================"
echo "Step 4/4: merge prefs bundle into deb"
echo "========================================"
DEB=$(ls packages/*.deb | head -1)
echo "deb: $DEB"
dpkg-deb -c "$DEB" | grep -q "PreferenceBundles/StatusBarNotifyPrefs" && {
  echo "prefs bundle already inside deb, nothing to merge"
} || {
  echo "merging prefs bundle manually..."
  rm -rf /tmp/debw && mkdir -p /tmp/debw
  dpkg-deb -x "$DEB" /tmp/debw/
  dpkg-deb -e "$DEB" /tmp/debw/DEBIAN
  BUNDLE_SRC=$(find . -path "*PreferenceBundles/StatusBarNotifyPrefs.bundle" -type d 2>/dev/null | grep -v "/tmp/debw" | head -1)
  echo "bundle src: $BUNDLE_SRC"
  if [ -n "$BUNDLE_SRC" ]; then
    mkdir -p /tmp/debw/var/jb/Library/PreferenceBundles/StatusBarNotifyPrefs.bundle
    cp -R "$BUNDLE_SRC/." /tmp/debw/var/jb/Library/PreferenceBundles/StatusBarNotifyPrefs.bundle/
    # make sure Info.plist is present (PreferenceLoader requires it)
    if [ ! -f /tmp/debw/var/jb/Library/PreferenceBundles/StatusBarNotifyPrefs.bundle/Info.plist ]; then
      cp StatusBarNotifyPrefs/Info.plist /tmp/debw/var/jb/Library/PreferenceBundles/StatusBarNotifyPrefs.bundle/Info.plist
    fi
    NEWDEB="packages/StatusBarNotifyAppIcons_arm64e_merged.deb"
    dpkg-deb -b /tmp/debw "$NEWDEB"
    echo "merged deb: $NEWDEB"
  else
    echo "ERROR: bundle build output not found"
    exit 1
  fi
}

echo "========================================"
echo "Final deb list:"
ls -la packages/*.deb
echo "BUILD SUCCESS"
